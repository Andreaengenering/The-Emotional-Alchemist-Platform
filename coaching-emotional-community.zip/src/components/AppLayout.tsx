import React, { useState, useEffect } from 'react';
import { useAppContext } from '@/contexts/AppContext';
import { useIsMobile } from '@/hooks/use-mobile';
import { supabase } from '@/lib/supabase';

// Components
import Header from './Header';
import HeroSection from './HeroSection';
import FeaturesSection from './FeaturesSection';
import TestimonialsSection from './TestimonialsSection';
import CoursesSection from './CoursesSection';
import CourseDetailSection from './CourseDetailSection';
import CommunitySection from './CommunitySection';
import StoreSection from './StoreSection';
import BookingSection from './BookingSection';
import PricingSection from './PricingSection';
import DashboardSection from './DashboardSection';
import JournalSection from './JournalSection';
import LibrarySection from './LibrarySection';
import AIAssistant from './AIAssistant';
import AuthModal from './AuthModal';
import Footer from './Footer';

const AppLayout: React.FC = () => {
  const { sidebarOpen, toggleSidebar } = useAppContext();
  const isMobile = useIsMobile();

  // App State
  const [currentView, setCurrentView] = useState('home');
  const [isLoggedIn, setIsLoggedIn] = useState(false);
  const [userTier, setUserTier] = useState<'free' | 'paid' | 'vip'>('free');
  const [userEmotion, setUserEmotion] = useState('');
  const [userId, setUserId] = useState<string>('');
  const [userEmail, setUserEmail] = useState<string>('');
  const [userName, setUserName] = useState<string>('');
  const [showAuthModal, setShowAuthModal] = useState(false);
  const [selectedCourse, setSelectedCourse] = useState<string | null>(null);
  const [purchasedProducts, setPurchasedProducts] = useState<Set<string>>(new Set());
  const [isLoading, setIsLoading] = useState(true);

  // Check for existing session on mount
  useEffect(() => {
    const checkSession = async () => {
      try {
        const { data: { session } } = await supabase.auth.getSession();
        
        if (session?.user) {
          // Fetch user profile from database
          const { data: profile } = await supabase
            .from('users')
            .select('*')
            .eq('id', session.user.id)
            .single();

          setIsLoggedIn(true);
          setUserId(session.user.id);
          setUserEmail(session.user.email || '');
          setUserName(profile?.full_name || session.user.user_metadata?.full_name || '');
          setUserTier((profile?.tier as 'free' | 'paid' | 'vip') || 'free');
          setUserEmotion(profile?.emotion_to_alchemize || '');

          // Fetch user purchases
          const { data: purchases } = await supabase
            .from('purchases')
            .select('product_id')
            .eq('user_id', session.user.id);

          if (purchases) {
            setPurchasedProducts(new Set(purchases.map(p => p.product_id)));
          }
        }
      } catch (error) {
        console.error('Session check error:', error);
      } finally {
        setIsLoading(false);
      }
    };

    checkSession();

    // Listen for auth state changes
    const { data: { subscription } } = supabase.auth.onAuthStateChange(async (event, session) => {
      if (event === 'SIGNED_IN' && session?.user) {
        // Fetch or create user profile
        const { data: profile } = await supabase
          .from('users')
          .select('*')
          .eq('id', session.user.id)
          .single();

        if (!profile) {
          // Create profile for OAuth users
          await supabase.from('users').insert({
            id: session.user.id,
            email: session.user.email,
            full_name: session.user.user_metadata?.full_name || '',
            tier: 'free',
            created_at: new Date().toISOString()
          });
        }

        setIsLoggedIn(true);
        setUserId(session.user.id);
        setUserEmail(session.user.email || '');
        setUserName(profile?.full_name || session.user.user_metadata?.full_name || '');
        setUserTier((profile?.tier as 'free' | 'paid' | 'vip') || 'free');
        setUserEmotion(profile?.emotion_to_alchemize || '');
        setCurrentView('dashboard');
      } else if (event === 'SIGNED_OUT') {
        setIsLoggedIn(false);
        setUserId('');
        setUserEmail('');
        setUserName('');
        setUserTier('free');
        setUserEmotion('');
        setPurchasedProducts(new Set());
        setCurrentView('home');
      }
    });

    return () => {
      subscription.unsubscribe();
    };
  }, []);

  // Handle login from AuthModal
  const handleLogin = (email: string, emotion: string, id: string, tier: string) => {
    setIsLoggedIn(true);
    setUserEmail(email);
    setUserEmotion(emotion);
    setUserId(id);
    setUserTier(tier as 'free' | 'paid' | 'vip');
    setCurrentView('dashboard');
  };

  // Handle logout
  const handleLogout = async () => {
    await supabase.auth.signOut();
    setIsLoggedIn(false);
    setUserId('');
    setUserEmail('');
    setUserName('');
    setUserTier('free');
    setUserEmotion('');
    setPurchasedProducts(new Set());
    setCurrentView('home');
  };

  // Scroll to top when view changes
  useEffect(() => {
    window.scrollTo({ top: 0, behavior: 'smooth' });
  }, [currentView]);

  // Render current view
  const renderView = () => {
    switch (currentView) {
      case 'home':
        return (
          <>
            <HeroSection 
              setCurrentView={setCurrentView} 
              setShowAuthModal={setShowAuthModal}
              isLoggedIn={isLoggedIn}
            />
            <FeaturesSection setCurrentView={setCurrentView} />
            <TestimonialsSection />
            <PricingSection 
              isLoggedIn={isLoggedIn}
              userTier={userTier}
              setShowAuthModal={setShowAuthModal}
            />
          </>
        );
      
      case 'courses':
        return (
          <CoursesSection 
            userTier={userTier}
            setCurrentView={setCurrentView}
            setSelectedCourse={setSelectedCourse}
          />
        );
      
      case 'course-detail':
        return selectedCourse ? (
          <CourseDetailSection 
            courseId={selectedCourse}
            userTier={userTier}
            setCurrentView={setCurrentView}
          />
        ) : (
          <CoursesSection 
            userTier={userTier}
            setCurrentView={setCurrentView}
            setSelectedCourse={setSelectedCourse}
          />
        );
      
      case 'community':
        return (
          <CommunitySection 
            isLoggedIn={isLoggedIn}
            userTier={userTier}
            setShowAuthModal={setShowAuthModal}
          />
        );
      
      case 'store':
        return (
          <StoreSection 
            isLoggedIn={isLoggedIn}
            purchasedProducts={purchasedProducts}
            setPurchasedProducts={setPurchasedProducts}
            setShowAuthModal={setShowAuthModal}
          />
        );
      
      case 'booking':
        return (
          <BookingSection 
            isLoggedIn={isLoggedIn}
            setShowAuthModal={setShowAuthModal}
          />
        );
      
      case 'pricing':
        return (
          <PricingSection 
            isLoggedIn={isLoggedIn}
            userTier={userTier}
            setShowAuthModal={setShowAuthModal}
          />
        );
      
      case 'dashboard':
        return isLoggedIn ? (
          <DashboardSection 
            userTier={userTier}
            userEmotion={userEmotion}
            setCurrentView={setCurrentView}
            setSelectedCourse={setSelectedCourse}
          />
        ) : (
          <>
            <HeroSection 
              setCurrentView={setCurrentView} 
              setShowAuthModal={setShowAuthModal}
              isLoggedIn={isLoggedIn}
            />
            <FeaturesSection setCurrentView={setCurrentView} />
          </>
        );
      
      case 'journal':
        return (
          <JournalSection 
            isLoggedIn={isLoggedIn}
            setShowAuthModal={setShowAuthModal}
          />
        );
      
      case 'library':
        return (
          <LibrarySection 
            isLoggedIn={isLoggedIn}
            purchasedProducts={purchasedProducts}
            setShowAuthModal={setShowAuthModal}
            setCurrentView={setCurrentView}
          />
        );
      
      default:
        return (
          <>
            <HeroSection 
              setCurrentView={setCurrentView} 
              setShowAuthModal={setShowAuthModal}
              isLoggedIn={isLoggedIn}
            />
            <FeaturesSection setCurrentView={setCurrentView} />
            <TestimonialsSection />
          </>
        );
    }
  };

  // Loading state
  if (isLoading) {
    return (
      <div className="min-h-screen bg-charcoal flex items-center justify-center">
        <div className="text-center">
          <div className="w-16 h-16 mx-auto mb-4 rounded-full bg-gradient-to-br from-crimson to-gold flex items-center justify-center animate-pulse">
            <span className="text-white font-serif text-2xl">E</span>
          </div>
          <p className="text-gray-400">Loading your sanctuary...</p>
        </div>
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-charcoal font-sans">
      {/* Header */}
      <Header 
        currentView={currentView}
        setCurrentView={setCurrentView}
        isLoggedIn={isLoggedIn}
        setShowAuthModal={setShowAuthModal}
        userTier={userTier}
        onLogout={handleLogout}
        userName={userName}
      />

      {/* Main Content */}
      <main className="pt-16 md:pt-20">
        {renderView()}
      </main>

      {/* Footer */}
      <Footer setCurrentView={setCurrentView} />

      {/* AI Assistant */}
      <AIAssistant 
        isLoggedIn={isLoggedIn}
        userEmotion={userEmotion}
        setCurrentView={setCurrentView}
      />

      {/* Auth Modal */}
      <AuthModal 
        isOpen={showAuthModal}
        onClose={() => setShowAuthModal(false)}
        onLogin={handleLogin}
      />
    </div>
  );
};

export default AppLayout;
