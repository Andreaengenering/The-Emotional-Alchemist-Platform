import React, { useState } from 'react';
import { ChevronLeft, ChevronRight, Quote, Star } from 'lucide-react';

const TESTIMONIALS = [
  {
    id: 1,
    name: 'Sarah M.',
    role: 'Alchemist Member',
    content: 'This platform changed my relationship with anxiety. The AI assistant helped me through a panic attack at 2am when I had no one else to turn to. The courses gave me tools I use every single day.',
    rating: 5
  },
  {
    id: 2,
    name: 'Michael R.',
    role: 'Sovereign Member',
    content: 'The 1:1 coaching sessions have been transformative. I finally understand why I react the way I do, and I have practical tools to respond differently. Worth every penny.',
    rating: 5
  },
  {
    id: 3,
    name: 'Jennifer L.',
    role: 'Alchemist Member',
    content: 'The community here is unlike anything I\'ve experienced. Everyone is so supportive and understanding. The live sessions are powerful—I always leave feeling more grounded.',
    rating: 5
  },
  {
    id: 4,
    name: 'David K.',
    role: 'Sovereign Member',
    content: 'I was skeptical about online coaching, but this exceeded all expectations. The nervous system course alone was worth the membership. I sleep better, I react less, I live more.',
    rating: 5
  },
  {
    id: 5,
    name: 'Amanda T.',
    role: 'Alchemist Member',
    content: 'The journaling feature with prompts has become my daily ritual. It\'s like having a therapist in my pocket. The progress I\'ve made in 3 months is remarkable.',
    rating: 5
  }
];

const TestimonialsSection: React.FC = () => {
  const [currentIndex, setCurrentIndex] = useState(0);

  const nextTestimonial = () => {
    setCurrentIndex((prev) => (prev + 1) % TESTIMONIALS.length);
  };

  const prevTestimonial = () => {
    setCurrentIndex((prev) => (prev - 1 + TESTIMONIALS.length) % TESTIMONIALS.length);
  };

  const visibleTestimonials = [
    TESTIMONIALS[currentIndex],
    TESTIMONIALS[(currentIndex + 1) % TESTIMONIALS.length],
    TESTIMONIALS[(currentIndex + 2) % TESTIMONIALS.length]
  ];

  return (
    <section className="py-24 px-4 sm:px-6 lg:px-8 bg-charcoal">
      <div className="max-w-7xl mx-auto">
        {/* Header */}
        <div className="text-center mb-16">
          <h2 className="text-3xl sm:text-4xl font-serif text-white mb-4">
            Voices from the{' '}
            <span className="text-transparent bg-clip-text bg-gradient-to-r from-crimson to-gold">
              Sanctuary
            </span>
          </h2>
          <p className="text-gray-400 max-w-2xl mx-auto">
            Real stories from real people on their transformation journey.
          </p>
        </div>

        {/* Testimonials Carousel */}
        <div className="relative">
          {/* Navigation Buttons */}
          <button
            onClick={prevTestimonial}
            className="absolute left-0 top-1/2 -translate-y-1/2 -translate-x-4 z-10 w-12 h-12 bg-white/5 border border-gold/20 rounded-full flex items-center justify-center text-gray-400 hover:text-white hover:border-gold/40 transition-colors hidden md:flex"
          >
            <ChevronLeft className="w-6 h-6" />
          </button>
          <button
            onClick={nextTestimonial}
            className="absolute right-0 top-1/2 -translate-y-1/2 translate-x-4 z-10 w-12 h-12 bg-white/5 border border-gold/20 rounded-full flex items-center justify-center text-gray-400 hover:text-white hover:border-gold/40 transition-colors hidden md:flex"
          >
            <ChevronRight className="w-6 h-6" />
          </button>

          {/* Testimonials Grid */}
          <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
            {visibleTestimonials.map((testimonial, index) => (
              <div
                key={`${testimonial.id}-${index}`}
                className={`p-8 bg-white/5 border border-gold/10 rounded-2xl transition-all duration-500 ${
                  index === 1 ? 'md:scale-105 md:border-gold/30 md:shadow-xl md:shadow-gold/5' : ''
                }`}
              >
                {/* Quote Icon */}
                <div className="w-10 h-10 bg-gold/20 rounded-lg flex items-center justify-center mb-6">
                  <Quote className="w-5 h-5 text-gold" />
                </div>

                {/* Rating */}
                <div className="flex items-center space-x-1 mb-4">
                  {[...Array(testimonial.rating)].map((_, i) => (
                    <Star key={i} className="w-4 h-4 text-gold fill-current" />
                  ))}
                </div>

                {/* Content */}
                <p className="text-gray-300 leading-relaxed mb-6">
                  "{testimonial.content}"
                </p>

                {/* Author */}
                <div className="flex items-center space-x-3">
                  <div className="w-10 h-10 rounded-full bg-gradient-to-br from-crimson/50 to-gold/50" />
                  <div>
                    <p className="text-white font-medium">{testimonial.name}</p>
                    <p className="text-gray-500 text-sm">{testimonial.role}</p>
                  </div>
                </div>
              </div>
            ))}
          </div>

          {/* Mobile Navigation */}
          <div className="flex items-center justify-center space-x-4 mt-8 md:hidden">
            <button
              onClick={prevTestimonial}
              className="w-10 h-10 bg-white/5 border border-gold/20 rounded-full flex items-center justify-center text-gray-400 hover:text-white"
            >
              <ChevronLeft className="w-5 h-5" />
            </button>
            <div className="flex items-center space-x-2">
              {TESTIMONIALS.map((_, index) => (
                <button
                  key={index}
                  onClick={() => setCurrentIndex(index)}
                  className={`w-2 h-2 rounded-full transition-colors ${
                    index === currentIndex ? 'bg-gold' : 'bg-white/20'
                  }`}
                />
              ))}
            </div>
            <button
              onClick={nextTestimonial}
              className="w-10 h-10 bg-white/5 border border-gold/20 rounded-full flex items-center justify-center text-gray-400 hover:text-white"
            >
              <ChevronRight className="w-5 h-5" />
            </button>
          </div>
        </div>

        {/* Stats */}
        <div className="mt-20 grid grid-cols-2 md:grid-cols-4 gap-8">
          {[
            { value: '2,500+', label: 'Active Members' },
            { value: '4.9/5', label: 'Average Rating' },
            { value: '50,000+', label: 'Lessons Completed' },
            { value: '98%', label: 'Would Recommend' }
          ].map((stat, index) => (
            <div key={index} className="text-center">
              <p className="text-3xl md:text-4xl font-bold text-transparent bg-clip-text bg-gradient-to-r from-crimson to-gold mb-2">
                {stat.value}
              </p>
              <p className="text-gray-500 text-sm">{stat.label}</p>
            </div>
          ))}
        </div>
      </div>
    </section>
  );
};

export default TestimonialsSection;
