import React, { useState, useRef, useEffect } from 'react';
import { MessageCircle, X, Send, Sparkles, AlertTriangle, Phone } from 'lucide-react';

interface Message {
  id: string;
  role: 'user' | 'assistant';
  content: string;
  timestamp: Date;
}

interface AIAssistantProps {
  isLoggedIn: boolean;
  userEmotion?: string;
  setCurrentView: (view: string) => void;
}

const CRISIS_KEYWORDS = ['suicide', 'kill myself', 'end my life', 'want to die', 'self-harm', 'hurt myself'];

const CRISIS_RESPONSE = {
  message: "I'm deeply concerned about what you've shared. Your safety matters more than anything else right now. Please reach out to a crisis helpline immediately:",
  resources: [
    { name: 'National Suicide Prevention Lifeline', number: '988' },
    { name: 'Crisis Text Line', number: 'Text HOME to 741741' },
    { name: 'International Association for Suicide Prevention', url: 'https://www.iasp.info/resources/Crisis_Centres/' }
  ]
};

const INITIAL_MESSAGES: Record<string, string> = {
  anxiety: "Welcome. I sense you are carrying anxiety today. You are safe here. Would you like a 3-minute nervous system regulation exercise before you explore?",
  fear: "Welcome. I see you are working with fear today. This is a brave step. You are safe here. Would you like a grounding exercise to help you feel more centered?",
  anger: "Welcome. I notice you are holding anger today. This emotion has wisdom within it. You are safe here. Would you like to explore what this anger is protecting?",
  numbness: "Welcome. I understand you are experiencing numbness. This is often the body's way of protecting you. You are safe here. Would you like a gentle body awareness exercise?",
  default: "Welcome to your sanctuary. I am The Emotional Alchemist, here to guide you on your healing journey. How may I support you today?"
};

const AIAssistant: React.FC<AIAssistantProps> = ({ isLoggedIn, userEmotion, setCurrentView }) => {
  const [isOpen, setIsOpen] = useState(false);
  const [messages, setMessages] = useState<Message[]>([]);
  const [inputValue, setInputValue] = useState('');
  const [isTyping, setIsTyping] = useState(false);
  const [showCrisisAlert, setShowCrisisAlert] = useState(false);
  const messagesEndRef = useRef<HTMLDivElement>(null);

  useEffect(() => {
    if (isOpen && messages.length === 0) {
      const initialMessage = userEmotion 
        ? INITIAL_MESSAGES[userEmotion] || INITIAL_MESSAGES.default
        : INITIAL_MESSAGES.default;
      
      setMessages([{
        id: '1',
        role: 'assistant',
        content: initialMessage,
        timestamp: new Date()
      }]);
    }
  }, [isOpen, userEmotion]);

  useEffect(() => {
    messagesEndRef.current?.scrollIntoView({ behavior: 'smooth' });
  }, [messages]);

  const checkForCrisis = (text: string): boolean => {
    const lowerText = text.toLowerCase();
    return CRISIS_KEYWORDS.some(keyword => lowerText.includes(keyword));
  };

  const generateResponse = (userMessage: string): string => {
    const lowerMessage = userMessage.toLowerCase();

    if (lowerMessage.includes('course') || lowerMessage.includes('learn')) {
      return "I'd be happy to guide you to our courses. We have several transformative programs available. The 'Biology of Your Inner Critic' is a wonderful starting point and it's completely free. Would you like me to take you there?";
    }

    if (lowerMessage.includes('book') || lowerMessage.includes('session') || lowerMessage.includes('coaching')) {
      return "It sounds like you might benefit from personalized 1:1 guidance. Our coaching sessions are designed to help you work through deep patterns. Would you like to book a session with our coach?";
    }

    if (lowerMessage.includes('yes') && messages.some(m => m.content.includes('book a session'))) {
      return "Wonderful! I'll guide you to our booking page where you can select a time that works for you. [BOOK_SESSION_BUTTON]";
    }

    if (lowerMessage.includes('exercise') || lowerMessage.includes('regulation') || lowerMessage.includes('grounding')) {
      return "Let's do a quick grounding exercise together:\n\n1. Place both feet flat on the floor\n2. Take a slow breath in for 4 counts\n3. Hold gently for 4 counts\n4. Release slowly for 6 counts\n5. Notice the support beneath you\n\nRepeat this 3 times. How do you feel now?";
    }

    if (lowerMessage.includes('anxious') || lowerMessage.includes('worried') || lowerMessage.includes('stress')) {
      return "I hear that you're experiencing anxiety. This is your nervous system trying to protect you. Remember: you are safe in this moment. Would you like me to guide you through a calming technique, or would you prefer to explore what might be triggering this feeling?";
    }

    if (lowerMessage.includes('sad') || lowerMessage.includes('depressed') || lowerMessage.includes('lonely')) {
      return "Thank you for sharing this with me. Sadness is a messenger—it often points to something we value or have lost. You don't have to carry this alone. I'm here with you. Would you like to journal about this feeling, or would a gentle meditation help right now?\n\n*Note: I am not a licensed therapist. If you're experiencing persistent depression, please consider reaching out to a mental health professional.*";
    }

    if (lowerMessage.includes('angry') || lowerMessage.includes('frustrated') || lowerMessage.includes('rage')) {
      return "Anger is a powerful emotion that often protects something vulnerable underneath. It's valid to feel this way. Before we explore further, let's make sure you're grounded. Take a deep breath with me. Now, what do you think this anger might be protecting?";
    }

    if (lowerMessage.includes('help') || lowerMessage.includes('support')) {
      return "I'm here to support you in several ways:\n\n• Guide you through courses and content\n• Offer nervous system regulation exercises\n• Help you navigate the platform\n• Provide emotional support and reflection\n• Connect you with coaching sessions\n\nWhat would be most helpful for you right now?";
    }

    return "Thank you for sharing that with me. Your feelings are valid, and this is a safe space to explore them. Would you like to:\n\n1. Try a grounding exercise\n2. Explore our courses on emotional regulation\n3. Book a 1:1 coaching session\n4. Simply continue sharing what's on your heart\n\nI'm here for whatever you need.";
  };

  const handleSend = () => {
    if (!inputValue.trim()) return;

    const userMessage: Message = {
      id: Date.now().toString(),
      role: 'user',
      content: inputValue,
      timestamp: new Date()
    };

    setMessages(prev => [...prev, userMessage]);
    setInputValue('');

    // Check for crisis keywords
    if (checkForCrisis(inputValue)) {
      setShowCrisisAlert(true);
      setMessages(prev => [...prev, {
        id: (Date.now() + 1).toString(),
        role: 'assistant',
        content: 'CRISIS_RESPONSE',
        timestamp: new Date()
      }]);
      return;
    }

    setIsTyping(true);

    // Simulate AI response delay
    setTimeout(() => {
      const response = generateResponse(inputValue);
      setMessages(prev => [...prev, {
        id: (Date.now() + 1).toString(),
        role: 'assistant',
        content: response,
        timestamp: new Date()
      }]);
      setIsTyping(false);
    }, 1000 + Math.random() * 1000);
  };

  const handleBookSession = () => {
    setIsOpen(false);
    setCurrentView('booking');
  };

  const renderMessage = (message: Message) => {
    if (message.content === 'CRISIS_RESPONSE') {
      return (
        <div className="bg-red-900/30 border border-red-500/50 rounded-lg p-4">
          <div className="flex items-start space-x-2 mb-3">
            <AlertTriangle className="w-5 h-5 text-red-400 flex-shrink-0 mt-0.5" />
            <p className="text-white text-sm">{CRISIS_RESPONSE.message}</p>
          </div>
          <div className="space-y-2 ml-7">
            {CRISIS_RESPONSE.resources.map((resource, idx) => (
              <div key={idx} className="flex items-center space-x-2 text-sm">
                <Phone className="w-4 h-4 text-red-400" />
                <span className="text-white font-medium">{resource.name}:</span>
                <span className="text-gold">{resource.number || resource.url}</span>
              </div>
            ))}
          </div>
        </div>
      );
    }

    // Check for book session button
    if (message.content.includes('[BOOK_SESSION_BUTTON]')) {
      const text = message.content.replace('[BOOK_SESSION_BUTTON]', '');
      return (
        <div>
          <p className="text-sm whitespace-pre-wrap">{text}</p>
          <button
            onClick={handleBookSession}
            className="mt-3 px-4 py-2 bg-gradient-to-r from-crimson to-gold text-white rounded-lg text-sm font-medium hover:opacity-90 transition-opacity"
          >
            Book a Session
          </button>
        </div>
      );
    }

    return <p className="text-sm whitespace-pre-wrap">{message.content}</p>;
  };

  return (
    <>
      {/* Floating Button */}
      <button
        onClick={() => setIsOpen(true)}
        className={`fixed bottom-6 right-6 z-50 w-14 h-14 bg-gradient-to-br from-crimson to-gold rounded-full shadow-lg shadow-crimson/30 flex items-center justify-center transition-all duration-300 hover:scale-110 ${isOpen ? 'hidden' : ''}`}
      >
        <MessageCircle className="w-6 h-6 text-white" />
        <span className="absolute top-0 right-0 w-3 h-3 bg-green-400 rounded-full border-2 border-charcoal animate-pulse" />
      </button>

      {/* Chat Window */}
      {isOpen && (
        <div className="fixed bottom-6 right-6 z-50 w-96 max-w-[calc(100vw-3rem)] h-[500px] max-h-[calc(100vh-6rem)] bg-charcoal border border-gold/30 rounded-2xl shadow-2xl flex flex-col overflow-hidden">
          {/* Header */}
          <div className="bg-gradient-to-r from-crimson/20 to-gold/20 border-b border-gold/20 p-4 flex items-center justify-between">
            <div className="flex items-center space-x-3">
              <div className="w-10 h-10 rounded-full bg-gradient-to-br from-crimson to-gold flex items-center justify-center">
                <Sparkles className="w-5 h-5 text-white" />
              </div>
              <div>
                <h3 className="text-white font-semibold text-sm">The Emotional Alchemist</h3>
                <p className="text-gold text-xs">Your 24/7 Guide</p>
              </div>
            </div>
            <button
              onClick={() => setIsOpen(false)}
              className="p-2 hover:bg-white/10 rounded-lg transition-colors"
            >
              <X className="w-5 h-5 text-gray-400" />
            </button>
          </div>

          {/* Messages */}
          <div className="flex-1 overflow-y-auto p-4 space-y-4">
            {messages.map((message) => (
              <div
                key={message.id}
                className={`flex ${message.role === 'user' ? 'justify-end' : 'justify-start'}`}
              >
                <div
                  className={`max-w-[80%] rounded-2xl px-4 py-3 ${
                    message.role === 'user'
                      ? 'bg-gradient-to-r from-crimson to-crimson/80 text-white'
                      : 'bg-white/10 text-gray-200'
                  }`}
                >
                  {renderMessage(message)}
                </div>
              </div>
            ))}
            
            {isTyping && (
              <div className="flex justify-start">
                <div className="bg-white/10 rounded-2xl px-4 py-3">
                  <div className="flex space-x-1">
                    <div className="w-2 h-2 bg-gold rounded-full animate-bounce" style={{ animationDelay: '0ms' }} />
                    <div className="w-2 h-2 bg-gold rounded-full animate-bounce" style={{ animationDelay: '150ms' }} />
                    <div className="w-2 h-2 bg-gold rounded-full animate-bounce" style={{ animationDelay: '300ms' }} />
                  </div>
                </div>
              </div>
            )}
            
            <div ref={messagesEndRef} />
          </div>

          {/* Input */}
          <div className="p-4 border-t border-gold/20">
            <div className="flex items-center space-x-2">
              <input
                type="text"
                value={inputValue}
                onChange={(e) => setInputValue(e.target.value)}
                onKeyPress={(e) => e.key === 'Enter' && handleSend()}
                placeholder="Share what's on your heart..."
                className="flex-1 bg-white/5 border border-gold/20 rounded-xl px-4 py-3 text-white placeholder-gray-500 text-sm focus:outline-none focus:border-gold/50 transition-colors"
              />
              <button
                onClick={handleSend}
                disabled={!inputValue.trim()}
                className="p-3 bg-gradient-to-r from-crimson to-gold rounded-xl text-white disabled:opacity-50 disabled:cursor-not-allowed hover:opacity-90 transition-opacity"
              >
                <Send className="w-5 h-5" />
              </button>
            </div>
            <p className="text-xs text-gray-500 mt-2 text-center">
              I am an AI assistant, not a licensed therapist.
            </p>
          </div>
        </div>
      )}
    </>
  );
};

export default AIAssistant;
