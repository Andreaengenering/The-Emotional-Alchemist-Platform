import React, { useState } from 'react';
import { Menu, X, User, LogIn, ChevronDown, LogOut, Settings, BookOpen, FileText, Library } from 'lucide-react';

interface HeaderProps {
  currentView: string;
  setCurrentView: (view: string) => void;
  isLoggedIn: boolean;
  setShowAuthModal: (show: boolean) => void;
  userTier: string;
  onLogout?: () => void;
  userName?: string;
}

const Header: React.FC<HeaderProps> = ({ 
  currentView, 
  setCurrentView, 
  isLoggedIn, 
  setShowAuthModal,
  userTier,
  onLogout,
  userName
}) => {
  const [mobileMenuOpen, setMobileMenuOpen] = useState(false);
  const [profileDropdownOpen, setProfileDropdownOpen] = useState(false);

  const navItems = [
    { id: 'home', label: 'Home' },
    { id: 'courses', label: 'Courses' },
    { id: 'community', label: 'Sanctuary' },
    { id: 'store', label: 'Store' },
    { id: 'booking', label: 'Book a Session' },
  ];

  const handleNavClick = (viewId: string) => {
    setCurrentView(viewId);
    setMobileMenuOpen(false);
  };

  const handleLogout = () => {
    setProfileDropdownOpen(false);
    if (onLogout) {
      onLogout();
    }
  };

  const getTierLabel = () => {
    switch (userTier) {
      case 'vip': return 'Sovereign';
      case 'paid': return 'Alchemist';
      default: return 'Seeker';
    }
  };

  return (
    <header className="fixed top-0 left-0 right-0 z-50 bg-charcoal/95 backdrop-blur-md border-b border-gold/20">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="flex items-center justify-between h-16 md:h-20">
          {/* Logo */}
          <div 
            className="flex items-center cursor-pointer group"
            onClick={() => handleNavClick('home')}
          >
            <div className="w-10 h-10 rounded-full bg-gradient-to-br from-crimson to-gold flex items-center justify-center mr-3 group-hover:scale-105 transition-transform">
              <span className="text-white font-serif text-xl">E</span>
            </div>
            <div className="hidden sm:block">
              <h1 className="text-white font-serif text-lg leading-tight">The Emotional</h1>
              <p className="text-gold text-xs tracking-widest uppercase">Alchemist</p>
            </div>
          </div>

          {/* Desktop Navigation */}
          <nav className="hidden md:flex items-center space-x-1">
            {navItems.map((item) => (
              <button
                key={item.id}
                onClick={() => handleNavClick(item.id)}
                className={`px-4 py-2 rounded-lg text-sm font-medium transition-all duration-200 ${
                  currentView === item.id
                    ? 'text-gold bg-gold/10'
                    : 'text-gray-300 hover:text-white hover:bg-white/5'
                }`}
              >
                {item.label}
              </button>
            ))}
          </nav>

          {/* Right side actions */}
          <div className="flex items-center space-x-3">
            {isLoggedIn ? (
              <div className="relative">
                <button
                  onClick={() => setProfileDropdownOpen(!profileDropdownOpen)}
                  className="flex items-center space-x-2 px-3 py-2 rounded-lg bg-white/5 hover:bg-white/10 transition-colors"
                >
                  <div className="w-8 h-8 rounded-full bg-gradient-to-br from-crimson to-gold flex items-center justify-center">
                    <User className="w-4 h-4 text-white" />
                  </div>
                  <span className="hidden sm:block text-white text-sm">
                    {userName || getTierLabel()}
                  </span>
                  <ChevronDown className={`w-4 h-4 text-gray-400 transition-transform ${profileDropdownOpen ? 'rotate-180' : ''}`} />
                </button>

                {profileDropdownOpen && (
                  <>
                    {/* Backdrop to close dropdown */}
                    <div 
                      className="fixed inset-0 z-10" 
                      onClick={() => setProfileDropdownOpen(false)}
                    />
                    <div className="absolute right-0 mt-2 w-56 bg-charcoal border border-gold/20 rounded-xl shadow-xl py-2 z-20">
                      {/* User info */}
                      <div className="px-4 py-3 border-b border-gold/10">
                        <p className="text-white font-medium text-sm">{userName || 'Alchemist'}</p>
                        <p className="text-gold text-xs">{getTierLabel()} Member</p>
                      </div>
                      
                      <button
                        onClick={() => { handleNavClick('dashboard'); setProfileDropdownOpen(false); }}
                        className="w-full px-4 py-2.5 text-left text-gray-300 hover:text-white hover:bg-white/5 text-sm flex items-center space-x-3"
                      >
                        <BookOpen className="w-4 h-4" />
                        <span>My Dashboard</span>
                      </button>
                      <button
                        onClick={() => { handleNavClick('journal'); setProfileDropdownOpen(false); }}
                        className="w-full px-4 py-2.5 text-left text-gray-300 hover:text-white hover:bg-white/5 text-sm flex items-center space-x-3"
                      >
                        <FileText className="w-4 h-4" />
                        <span>My Journal</span>
                      </button>
                      <button
                        onClick={() => { handleNavClick('library'); setProfileDropdownOpen(false); }}
                        className="w-full px-4 py-2.5 text-left text-gray-300 hover:text-white hover:bg-white/5 text-sm flex items-center space-x-3"
                      >
                        <Library className="w-4 h-4" />
                        <span>My Library</span>
                      </button>
                      <button
                        onClick={() => { handleNavClick('pricing'); setProfileDropdownOpen(false); }}
                        className="w-full px-4 py-2.5 text-left text-gray-300 hover:text-white hover:bg-white/5 text-sm flex items-center space-x-3"
                      >
                        <Settings className="w-4 h-4" />
                        <span>Manage Subscription</span>
                      </button>
                      
                      <hr className="my-2 border-gold/10" />
                      
                      <button
                        onClick={handleLogout}
                        className="w-full px-4 py-2.5 text-left text-crimson hover:bg-white/5 text-sm flex items-center space-x-3"
                      >
                        <LogOut className="w-4 h-4" />
                        <span>Sign Out</span>
                      </button>
                    </div>
                  </>
                )}
              </div>
            ) : (
              <button
                onClick={() => setShowAuthModal(true)}
                className="flex items-center space-x-2 px-4 py-2 bg-gradient-to-r from-crimson to-crimson/80 hover:from-crimson/90 hover:to-crimson/70 text-white rounded-lg font-medium text-sm transition-all duration-200 hover:shadow-lg hover:shadow-crimson/20"
              >
                <LogIn className="w-4 h-4" />
                <span>Enter the Sanctuary</span>
              </button>
            )}

            {/* Mobile menu button */}
            <button
              onClick={() => setMobileMenuOpen(!mobileMenuOpen)}
              className="md:hidden p-2 rounded-lg text-gray-300 hover:text-white hover:bg-white/5"
            >
              {mobileMenuOpen ? <X className="w-6 h-6" /> : <Menu className="w-6 h-6" />}
            </button>
          </div>
        </div>

        {/* Mobile Navigation */}
        {mobileMenuOpen && (
          <div className="md:hidden py-4 border-t border-gold/10">
            <nav className="flex flex-col space-y-1">
              {navItems.map((item) => (
                <button
                  key={item.id}
                  onClick={() => handleNavClick(item.id)}
                  className={`px-4 py-3 rounded-lg text-left font-medium transition-all duration-200 ${
                    currentView === item.id
                      ? 'text-gold bg-gold/10'
                      : 'text-gray-300 hover:text-white hover:bg-white/5'
                  }`}
                >
                  {item.label}
                </button>
              ))}
              {isLoggedIn && (
                <>
                  <hr className="my-2 border-gold/10" />
                  <button
                    onClick={() => handleNavClick('dashboard')}
                    className="px-4 py-3 rounded-lg text-left text-gray-300 hover:text-white hover:bg-white/5"
                  >
                    My Dashboard
                  </button>
                  <button
                    onClick={() => handleNavClick('journal')}
                    className="px-4 py-3 rounded-lg text-left text-gray-300 hover:text-white hover:bg-white/5"
                  >
                    My Journal
                  </button>
                  <button
                    onClick={handleLogout}
                    className="px-4 py-3 rounded-lg text-left text-crimson hover:bg-white/5"
                  >
                    Sign Out
                  </button>
                </>
              )}
            </nav>
          </div>
        )}
      </div>
    </header>
  );
};

export default Header;
