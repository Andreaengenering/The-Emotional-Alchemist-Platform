import React from 'react';
import { Download, FileText, Headphones, Video, BookOpen, Lock } from 'lucide-react';
import { PRODUCTS } from '@/lib/constants';

interface LibrarySectionProps {
  isLoggedIn: boolean;
  purchasedProducts: Set<string>;
  setShowAuthModal: (show: boolean) => void;
  setCurrentView?: (view: string) => void;
}

const LibrarySection: React.FC<LibrarySectionProps> = ({ 
  isLoggedIn, 
  purchasedProducts, 
  setShowAuthModal,
  setCurrentView
}) => {

  const purchasedItems = PRODUCTS.filter(p => purchasedProducts.has(p.id));

  const getTypeIcon = (type: string) => {
    switch (type) {
      case 'pdf':
        return <FileText className="w-5 h-5" />;
      case 'audio':
        return <Headphones className="w-5 h-5" />;
      case 'video':
        return <Video className="w-5 h-5" />;
      default:
        return <FileText className="w-5 h-5" />;
    }
  };

  if (!isLoggedIn) {
    return (
      <section className="py-20 px-4 sm:px-6 lg:px-8 bg-charcoal min-h-screen flex items-center justify-center">
        <div className="text-center max-w-md">
          <div className="w-20 h-20 bg-gold/20 rounded-full flex items-center justify-center mx-auto mb-6">
            <Lock className="w-10 h-10 text-gold" />
          </div>
          <h2 className="text-2xl font-serif text-white mb-4">Your Personal Library</h2>
          <p className="text-gray-400 mb-6">
            Sign in to access your purchased resources and downloads.
          </p>
          <button
            onClick={() => setShowAuthModal(true)}
            className="px-8 py-3 bg-gradient-to-r from-crimson to-gold text-white rounded-xl font-semibold hover:opacity-90 transition-opacity"
          >
            Enter the Sanctuary
          </button>
        </div>
      </section>
    );
  }

  return (
    <section className="py-20 px-4 sm:px-6 lg:px-8 bg-charcoal min-h-screen">
      <div className="max-w-5xl mx-auto">
        {/* Header */}
        <div className="text-center mb-12">
          <h2 className="text-3xl sm:text-4xl font-serif text-white mb-4">
            My <span className="text-transparent bg-clip-text bg-gradient-to-r from-crimson to-gold">Library</span>
          </h2>
          <p className="text-gray-400">
            Access all your purchased resources in one place.
          </p>
        </div>

        {/* Library Items */}
        {purchasedItems.length > 0 ? (
          <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
            {purchasedItems.map((item) => (
              <div
                key={item.id}
                className="flex items-center space-x-4 p-6 bg-white/5 border border-gold/10 rounded-2xl hover:border-gold/30 transition-all"
              >
                <img
                  src={item.thumbnail}
                  alt={item.title}
                  className="w-20 h-20 object-cover rounded-xl"
                />
                <div className="flex-1">
                  <div className="flex items-center space-x-2 mb-1">
                    <span className="text-gold">{getTypeIcon(item.type)}</span>
                    <span className="text-gray-500 text-xs uppercase">{item.type}</span>
                  </div>
                  <h3 className="text-white font-semibold mb-1">{item.title}</h3>
                  <p className="text-gray-400 text-sm line-clamp-1">{item.description}</p>
                </div>
                <button className="flex items-center space-x-2 px-4 py-2 bg-gold/20 text-gold rounded-xl font-medium text-sm hover:bg-gold/30 transition-colors">
                  <Download className="w-4 h-4" />
                  <span>Download</span>
                </button>
              </div>
            ))}
          </div>
        ) : (
          <div className="text-center py-16 bg-white/5 border border-gold/10 rounded-2xl">
            <BookOpen className="w-16 h-16 text-gray-600 mx-auto mb-4" />
            <h3 className="text-white font-semibold mb-2">Your library is empty</h3>
            <p className="text-gray-500 mb-6">
              Purchase resources from the store to add them to your library.
            </p>
            <button 
              onClick={() => setCurrentView && setCurrentView('store')}
              className="px-6 py-2 bg-gradient-to-r from-crimson to-gold text-white rounded-xl font-medium hover:opacity-90 transition-opacity"
            >
              Browse Store
            </button>

          </div>
        )}
      </div>
    </section>
  );
};

export default LibrarySection;
