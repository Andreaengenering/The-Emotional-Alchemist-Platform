import React from 'react';
import { Clock, BookOpen, Lock, Play, CheckCircle } from 'lucide-react';

interface Course {
  id: string;
  title: string;
  description: string;
  thumbnail: string;
  tier: string;
  duration: number;
  lessons: number;
  progress: number;
}

interface CourseCardProps {
  course: Course;
  userTier: string;
  onSelect: (courseId: string) => void;
}

const CourseCard: React.FC<CourseCardProps> = ({ course, userTier, onSelect }) => {
  const tierOrder = { free: 0, paid: 1, vip: 2 };
  const hasAccess = tierOrder[userTier as keyof typeof tierOrder] >= tierOrder[course.tier as keyof typeof tierOrder];
  const isCompleted = course.progress === 100;
  const isInProgress = course.progress > 0 && course.progress < 100;

  const getTierBadge = () => {
    switch (course.tier) {
      case 'free':
        return (
          <span className="px-2 py-1 bg-green-500/20 text-green-400 text-xs font-medium rounded-full">
            Free
          </span>
        );
      case 'paid':
        return (
          <span className="px-2 py-1 bg-gold/20 text-gold text-xs font-medium rounded-full">
            Alchemist
          </span>
        );
      case 'vip':
        return (
          <span className="px-2 py-1 bg-crimson/20 text-crimson text-xs font-medium rounded-full">
            Sovereign
          </span>
        );
      default:
        return null;
    }
  };

  return (
    <div
      onClick={() => hasAccess && onSelect(course.id)}
      className={`group relative bg-white/5 border border-gold/10 rounded-2xl overflow-hidden transition-all duration-300 ${
        hasAccess 
          ? 'cursor-pointer hover:border-gold/30 hover:shadow-xl hover:shadow-gold/5 hover:-translate-y-1' 
          : 'opacity-75'
      }`}
    >
      {/* Thumbnail */}
      <div className="relative aspect-[4/3] overflow-hidden">
        <img
          src={course.thumbnail}
          alt={course.title}
          className="w-full h-full object-cover transition-transform duration-500 group-hover:scale-110"
        />
        <div className="absolute inset-0 bg-gradient-to-t from-charcoal via-transparent to-transparent" />
        
        {/* Lock overlay for inaccessible courses */}
        {!hasAccess && (
          <div className="absolute inset-0 bg-charcoal/60 flex items-center justify-center">
            <div className="text-center">
              <Lock className="w-8 h-8 text-gold mx-auto mb-2" />
              <p className="text-gold text-sm font-medium">Upgrade to Access</p>
            </div>
          </div>
        )}

        {/* Play button overlay */}
        {hasAccess && (
          <div className="absolute inset-0 flex items-center justify-center opacity-0 group-hover:opacity-100 transition-opacity">
            <div className="w-16 h-16 bg-gold/90 rounded-full flex items-center justify-center shadow-lg">
              <Play className="w-6 h-6 text-charcoal ml-1" />
            </div>
          </div>
        )}

        {/* Progress bar */}
        {isInProgress && (
          <div className="absolute bottom-0 left-0 right-0 h-1 bg-white/20">
            <div 
              className="h-full bg-gradient-to-r from-crimson to-gold transition-all duration-300"
              style={{ width: `${course.progress}%` }}
            />
          </div>
        )}

        {/* Completed badge */}
        {isCompleted && (
          <div className="absolute top-3 right-3 bg-green-500 rounded-full p-1">
            <CheckCircle className="w-5 h-5 text-white" />
          </div>
        )}

        {/* Tier badge */}
        <div className="absolute top-3 left-3">
          {getTierBadge()}
        </div>
      </div>

      {/* Content */}
      <div className="p-5">
        <h3 className="text-white font-semibold text-lg mb-2 line-clamp-2 group-hover:text-gold transition-colors">
          {course.title}
        </h3>
        <p className="text-gray-400 text-sm mb-4 line-clamp-2">
          {course.description}
        </p>

        {/* Meta info */}
        <div className="flex items-center justify-between text-sm text-gray-500">
          <div className="flex items-center space-x-1">
            <Clock className="w-4 h-4" />
            <span>{course.duration} min</span>
          </div>
          <div className="flex items-center space-x-1">
            <BookOpen className="w-4 h-4" />
            <span>{course.lessons} lessons</span>
          </div>
        </div>

        {/* Progress indicator */}
        {isInProgress && (
          <div className="mt-3 pt-3 border-t border-gold/10">
            <div className="flex items-center justify-between text-xs">
              <span className="text-gray-400">Progress</span>
              <span className="text-gold font-medium">{course.progress}%</span>
            </div>
          </div>
        )}
      </div>
    </div>
  );
};

export default CourseCard;
