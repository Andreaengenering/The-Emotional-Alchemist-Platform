import React, { useState } from 'react';
import { Heart, MessageCircle, Share2, Pin, Send, Image, Video, Smile, MoreHorizontal, User } from 'lucide-react';
import { COMMUNITY_POSTS, IMAGES } from '@/lib/constants';

interface Post {
  id: string;
  author: string;
  avatar: string | null;
  content: string;
  isAdmin: boolean;
  isPinned: boolean;
  likes: number;
  comments: number;
  createdAt: string;
}

interface CommunitySectionProps {
  isLoggedIn: boolean;
  userTier: string;
  setShowAuthModal: (show: boolean) => void;
}

const CommunitySection: React.FC<CommunitySectionProps> = ({ isLoggedIn, userTier, setShowAuthModal }) => {
  const [posts, setPosts] = useState<Post[]>(COMMUNITY_POSTS);
  const [newPostContent, setNewPostContent] = useState('');
  const [likedPosts, setLikedPosts] = useState<Set<string>>(new Set());
  const [expandedComments, setExpandedComments] = useState<Set<string>>(new Set());
  const [commentInputs, setCommentInputs] = useState<Record<string, string>>({});

  const canPost = isLoggedIn && userTier !== 'free';

  const handleLike = (postId: string) => {
    if (!isLoggedIn) {
      setShowAuthModal(true);
      return;
    }

    setLikedPosts(prev => {
      const newSet = new Set(prev);
      if (newSet.has(postId)) {
        newSet.delete(postId);
      } else {
        newSet.add(postId);
      }
      return newSet;
    });

    setPosts(prev => prev.map(post => {
      if (post.id === postId) {
        return {
          ...post,
          likes: likedPosts.has(postId) ? post.likes - 1 : post.likes + 1
        };
      }
      return post;
    }));
  };

  const handlePost = () => {
    if (!newPostContent.trim() || !canPost) return;

    const newPost: Post = {
      id: Date.now().toString(),
      author: 'You',
      avatar: null,
      content: newPostContent,
      isAdmin: false,
      isPinned: false,
      likes: 0,
      comments: 0,
      createdAt: new Date().toISOString()
    };

    setPosts([newPost, ...posts]);
    setNewPostContent('');
  };

  const toggleComments = (postId: string) => {
    setExpandedComments(prev => {
      const newSet = new Set(prev);
      if (newSet.has(postId)) {
        newSet.delete(postId);
      } else {
        newSet.add(postId);
      }
      return newSet;
    });
  };

  const formatTimeAgo = (dateString: string) => {
    const date = new Date(dateString);
    const now = new Date();
    const diffMs = now.getTime() - date.getTime();
    const diffMins = Math.floor(diffMs / 60000);
    const diffHours = Math.floor(diffMs / 3600000);
    const diffDays = Math.floor(diffMs / 86400000);

    if (diffMins < 60) return `${diffMins}m ago`;
    if (diffHours < 24) return `${diffHours}h ago`;
    return `${diffDays}d ago`;
  };

  return (
    <section className="py-20 px-4 sm:px-6 lg:px-8 bg-charcoal min-h-screen">
      <div className="max-w-3xl mx-auto">
        {/* Header */}
        <div className="text-center mb-12">
          <h2 className="text-3xl sm:text-4xl font-serif text-white mb-4">
            The <span className="text-transparent bg-clip-text bg-gradient-to-r from-crimson to-gold">Sanctuary</span>
          </h2>
          <p className="text-gray-400">
            A sacred space for connection, growth, and shared transformation.
          </p>
        </div>

        {/* Live Stream Banner */}
        <div className="mb-8 p-6 bg-gradient-to-r from-crimson/20 to-gold/20 border border-gold/30 rounded-2xl">
          <div className="flex items-center justify-between">
            <div className="flex items-center space-x-4">
              <div className="w-12 h-12 rounded-full bg-crimson/30 flex items-center justify-center">
                <Video className="w-6 h-6 text-crimson" />
              </div>
              <div>
                <h3 className="text-white font-semibold">Upcoming Live Alchemy</h3>
                <p className="text-gray-400 text-sm">Friday at 7:00 PM EST</p>
              </div>
            </div>
            <div className="text-right">
              <p className="text-gold text-sm font-medium">2 days, 14 hours</p>
              <button className="mt-1 text-xs text-gray-400 hover:text-white transition-colors">
                Add to Calendar
              </button>
            </div>
          </div>
        </div>

        {/* Post Composer */}
        <div className="mb-8 p-6 bg-white/5 border border-gold/10 rounded-2xl">
          {canPost ? (
            <>
              <div className="flex items-start space-x-4">
                <div className="w-10 h-10 rounded-full bg-gradient-to-br from-crimson to-gold flex items-center justify-center flex-shrink-0">
                  <User className="w-5 h-5 text-white" />
                </div>
                <textarea
                  value={newPostContent}
                  onChange={(e) => setNewPostContent(e.target.value)}
                  placeholder="Share your thoughts with the community..."
                  className="flex-1 bg-transparent text-white placeholder-gray-500 resize-none focus:outline-none min-h-[80px]"
                />
              </div>
              <div className="flex items-center justify-between mt-4 pt-4 border-t border-gold/10">
                <div className="flex items-center space-x-2">
                  <button className="p-2 text-gray-500 hover:text-gold hover:bg-gold/10 rounded-lg transition-colors">
                    <Image className="w-5 h-5" />
                  </button>
                  <button className="p-2 text-gray-500 hover:text-gold hover:bg-gold/10 rounded-lg transition-colors">
                    <Smile className="w-5 h-5" />
                  </button>
                </div>
                <button
                  onClick={handlePost}
                  disabled={!newPostContent.trim()}
                  className="px-6 py-2 bg-gradient-to-r from-crimson to-gold text-white rounded-xl font-medium text-sm disabled:opacity-50 disabled:cursor-not-allowed hover:opacity-90 transition-opacity"
                >
                  Post
                </button>
              </div>
            </>
          ) : (
            <div className="text-center py-4">
              <p className="text-gray-400 mb-3">
                {isLoggedIn 
                  ? 'Upgrade to Alchemist tier to participate in the community.'
                  : 'Sign in to participate in the community.'}
              </p>
              <button
                onClick={() => setShowAuthModal(true)}
                className="px-6 py-2 bg-gradient-to-r from-crimson to-gold text-white rounded-xl font-medium text-sm hover:opacity-90 transition-opacity"
              >
                {isLoggedIn ? 'Upgrade Now' : 'Enter the Sanctuary'}
              </button>
            </div>
          )}
        </div>

        {/* Posts Feed */}
        <div className="space-y-6">
          {posts.map((post) => (
            <article
              key={post.id}
              className={`p-6 bg-white/5 border rounded-2xl transition-all ${
                post.isPinned ? 'border-gold/30' : 'border-gold/10'
              }`}
            >
              {/* Pinned indicator */}
              {post.isPinned && (
                <div className="flex items-center space-x-2 text-gold text-xs mb-4">
                  <Pin className="w-3 h-3" />
                  <span>Pinned Post</span>
                </div>
              )}

              {/* Author */}
              <div className="flex items-center justify-between mb-4">
                <div className="flex items-center space-x-3">
                  {post.avatar ? (
                    <img
                      src={post.avatar}
                      alt={post.author}
                      className="w-10 h-10 rounded-full object-cover"
                    />
                  ) : (
                    <div className="w-10 h-10 rounded-full bg-gradient-to-br from-crimson/50 to-gold/50 flex items-center justify-center">
                      <User className="w-5 h-5 text-white" />
                    </div>
                  )}
                  <div>
                    <div className="flex items-center space-x-2">
                      <span className="text-white font-medium">{post.author}</span>
                      {post.isAdmin && (
                        <span className="px-2 py-0.5 bg-gold/20 text-gold text-xs rounded-full">
                          Coach
                        </span>
                      )}
                    </div>
                    <span className="text-gray-500 text-xs">{formatTimeAgo(post.createdAt)}</span>
                  </div>
                </div>
                <button className="p-2 text-gray-500 hover:text-white hover:bg-white/5 rounded-lg transition-colors">
                  <MoreHorizontal className="w-5 h-5" />
                </button>
              </div>

              {/* Content */}
              <p className="text-gray-300 leading-relaxed mb-4 whitespace-pre-wrap">
                {post.content}
              </p>

              {/* Actions */}
              <div className="flex items-center space-x-6 pt-4 border-t border-gold/10">
                <button
                  onClick={() => handleLike(post.id)}
                  className={`flex items-center space-x-2 transition-colors ${
                    likedPosts.has(post.id) ? 'text-crimson' : 'text-gray-500 hover:text-crimson'
                  }`}
                >
                  <Heart className={`w-5 h-5 ${likedPosts.has(post.id) ? 'fill-current' : ''}`} />
                  <span className="text-sm">{post.likes}</span>
                </button>
                <button
                  onClick={() => toggleComments(post.id)}
                  className="flex items-center space-x-2 text-gray-500 hover:text-gold transition-colors"
                >
                  <MessageCircle className="w-5 h-5" />
                  <span className="text-sm">{post.comments}</span>
                </button>
                <button className="flex items-center space-x-2 text-gray-500 hover:text-white transition-colors">
                  <Share2 className="w-5 h-5" />
                  <span className="text-sm">Share</span>
                </button>
              </div>

              {/* Comments Section */}
              {expandedComments.has(post.id) && (
                <div className="mt-4 pt-4 border-t border-gold/10">
                  {/* Sample comments */}
                  <div className="space-y-4 mb-4">
                    <div className="flex items-start space-x-3">
                      <div className="w-8 h-8 rounded-full bg-gradient-to-br from-crimson/30 to-gold/30 flex items-center justify-center flex-shrink-0">
                        <User className="w-4 h-4 text-white" />
                      </div>
                      <div>
                        <p className="text-white text-sm">
                          <span className="font-medium">Sarah M.</span>{' '}
                          <span className="text-gray-400">This resonates so deeply. Thank you for creating this space.</span>
                        </p>
                        <span className="text-gray-500 text-xs">2h ago</span>
                      </div>
                    </div>
                  </div>

                  {/* Comment input */}
                  {canPost && (
                    <div className="flex items-center space-x-3">
                      <div className="w-8 h-8 rounded-full bg-gradient-to-br from-crimson to-gold flex items-center justify-center flex-shrink-0">
                        <User className="w-4 h-4 text-white" />
                      </div>
                      <input
                        type="text"
                        placeholder="Write a comment..."
                        value={commentInputs[post.id] || ''}
                        onChange={(e) => setCommentInputs(prev => ({ ...prev, [post.id]: e.target.value }))}
                        className="flex-1 bg-white/5 border border-gold/20 rounded-xl px-4 py-2 text-white text-sm placeholder-gray-500 focus:outline-none focus:border-gold/50"
                      />
                      <button className="p-2 text-gold hover:bg-gold/10 rounded-lg transition-colors">
                        <Send className="w-5 h-5" />
                      </button>
                    </div>
                  )}
                </div>
              )}
            </article>
          ))}
        </div>
      </div>
    </section>
  );
};

export default CommunitySection;
