import React, { useState, useEffect } from 'react';
import { BookOpen, Plus, Save, Trash2, Calendar, Search, Lock, ChevronRight } from 'lucide-react';

interface JournalEntry {
  id: string;
  title: string;
  content: string;
  createdAt: Date;
  updatedAt: Date;
  lessonId?: string;
}

interface JournalSectionProps {
  isLoggedIn: boolean;
  setShowAuthModal: (show: boolean) => void;
}

const JOURNAL_PROMPTS = [
  "What emotion is present for me right now?",
  "What is my inner critic saying today, and what might be underneath that voice?",
  "Where do I feel tension in my body, and what might it be holding?",
  "What boundary do I need to set or honor today?",
  "What am I grateful for in this moment?",
  "What pattern am I noticing in my reactions lately?",
  "If my emotions could speak, what would they say?",
  "What does my nervous system need right now?"
];

const JournalSection: React.FC<JournalSectionProps> = ({ isLoggedIn, setShowAuthModal }) => {
  const [entries, setEntries] = useState<JournalEntry[]>([
    {
      id: '1',
      title: 'First Day in the Sanctuary',
      content: 'Today I started my journey with The Emotional Alchemist. I chose to work on anxiety as my primary emotion to transform. The AI assistant guided me through a breathing exercise that helped me feel more grounded...',
      createdAt: new Date(Date.now() - 3 * 24 * 60 * 60 * 1000),
      updatedAt: new Date(Date.now() - 3 * 24 * 60 * 60 * 1000)
    },
    {
      id: '2',
      title: 'Reflection on Module 1',
      content: 'The biology of the inner critic is fascinating. I never realized how much my self-criticism was tied to my nervous system response. When I feel unsafe, my inner critic gets louder...',
      createdAt: new Date(Date.now() - 1 * 24 * 60 * 60 * 1000),
      updatedAt: new Date(Date.now() - 1 * 24 * 60 * 60 * 1000),
      lessonId: '11111111-1111-1111-1111-111111111111'
    }
  ]);
  const [selectedEntry, setSelectedEntry] = useState<JournalEntry | null>(null);
  const [isEditing, setIsEditing] = useState(false);
  const [editTitle, setEditTitle] = useState('');
  const [editContent, setEditContent] = useState('');
  const [searchQuery, setSearchQuery] = useState('');
  const [saveStatus, setSaveStatus] = useState<'saved' | 'saving' | 'unsaved'>('saved');
  const [showPrompts, setShowPrompts] = useState(false);

  // Auto-save functionality
  useEffect(() => {
    if (!isEditing || !selectedEntry) return;

    const timer = setTimeout(() => {
      if (editContent !== selectedEntry.content || editTitle !== selectedEntry.title) {
        setSaveStatus('saving');
        // Simulate save
        setTimeout(() => {
          setEntries(prev => prev.map(entry => 
            entry.id === selectedEntry.id 
              ? { ...entry, title: editTitle, content: editContent, updatedAt: new Date() }
              : entry
          ));
          setSaveStatus('saved');
        }, 500);
      }
    }, 1000);

    return () => clearTimeout(timer);
  }, [editContent, editTitle, isEditing, selectedEntry]);

  if (!isLoggedIn) {
    return (
      <section className="py-20 px-4 sm:px-6 lg:px-8 bg-charcoal min-h-screen flex items-center justify-center">
        <div className="text-center max-w-md">
          <div className="w-20 h-20 bg-gold/20 rounded-full flex items-center justify-center mx-auto mb-6">
            <Lock className="w-10 h-10 text-gold" />
          </div>
          <h2 className="text-2xl font-serif text-white mb-4">Your Private Sanctuary</h2>
          <p className="text-gray-400 mb-6">
            Sign in to access your personal journal—a safe space for reflection and growth.
          </p>
          <button
            onClick={() => setShowAuthModal(true)}
            className="px-8 py-3 bg-gradient-to-r from-crimson to-gold text-white rounded-xl font-semibold hover:opacity-90 transition-opacity"
          >
            Enter the Sanctuary
          </button>
        </div>
      </section>
    );
  }

  const filteredEntries = entries.filter(entry =>
    entry.title.toLowerCase().includes(searchQuery.toLowerCase()) ||
    entry.content.toLowerCase().includes(searchQuery.toLowerCase())
  );

  const createNewEntry = () => {
    const newEntry: JournalEntry = {
      id: Date.now().toString(),
      title: 'Untitled Entry',
      content: '',
      createdAt: new Date(),
      updatedAt: new Date()
    };
    setEntries([newEntry, ...entries]);
    setSelectedEntry(newEntry);
    setEditTitle(newEntry.title);
    setEditContent(newEntry.content);
    setIsEditing(true);
  };

  const selectEntry = (entry: JournalEntry) => {
    setSelectedEntry(entry);
    setEditTitle(entry.title);
    setEditContent(entry.content);
    setIsEditing(true);
  };

  const deleteEntry = (entryId: string) => {
    if (confirm('Are you sure you want to delete this entry?')) {
      setEntries(prev => prev.filter(e => e.id !== entryId));
      if (selectedEntry?.id === entryId) {
        setSelectedEntry(null);
        setIsEditing(false);
      }
    }
  };

  const insertPrompt = (prompt: string) => {
    setEditContent(prev => prev + (prev ? '\n\n' : '') + prompt + '\n');
    setShowPrompts(false);
  };

  const formatDate = (date: Date) => {
    return date.toLocaleDateString('en-US', { 
      month: 'short', 
      day: 'numeric',
      year: 'numeric'
    });
  };

  return (
    <section className="py-20 px-4 sm:px-6 lg:px-8 bg-charcoal min-h-screen">
      <div className="max-w-7xl mx-auto">
        {/* Header */}
        <div className="flex flex-col sm:flex-row items-start sm:items-center justify-between gap-4 mb-8">
          <div>
            <h2 className="text-3xl font-serif text-white mb-2">
              The Alchemist's <span className="text-transparent bg-clip-text bg-gradient-to-r from-crimson to-gold">Mirror</span>
            </h2>
            <p className="text-gray-400">Your private space for reflection and transformation.</p>
          </div>
          <button
            onClick={createNewEntry}
            className="flex items-center space-x-2 px-6 py-3 bg-gradient-to-r from-crimson to-gold text-white rounded-xl font-medium hover:opacity-90 transition-opacity"
          >
            <Plus className="w-5 h-5" />
            <span>New Entry</span>
          </button>
        </div>

        <div className="grid grid-cols-1 lg:grid-cols-3 gap-8">
          {/* Entries List */}
          <div className="lg:col-span-1">
            {/* Search */}
            <div className="relative mb-4">
              <Search className="absolute left-4 top-1/2 transform -translate-y-1/2 w-5 h-5 text-gray-500" />
              <input
                type="text"
                placeholder="Search entries..."
                value={searchQuery}
                onChange={(e) => setSearchQuery(e.target.value)}
                className="w-full pl-12 pr-4 py-3 bg-white/5 border border-gold/20 rounded-xl text-white placeholder-gray-500 focus:outline-none focus:border-gold/50 transition-colors"
              />
            </div>

            {/* Entries */}
            <div className="space-y-3 max-h-[600px] overflow-y-auto pr-2">
              {filteredEntries.length > 0 ? (
                filteredEntries.map((entry) => (
                  <div
                    key={entry.id}
                    onClick={() => selectEntry(entry)}
                    className={`p-4 rounded-xl cursor-pointer transition-all ${
                      selectedEntry?.id === entry.id
                        ? 'bg-gold/10 border border-gold/30'
                        : 'bg-white/5 border border-gold/10 hover:border-gold/20'
                    }`}
                  >
                    <div className="flex items-start justify-between">
                      <div className="flex-1 min-w-0">
                        <h4 className="text-white font-medium truncate">{entry.title}</h4>
                        <p className="text-gray-500 text-sm mt-1 line-clamp-2">{entry.content || 'Empty entry...'}</p>
                        <div className="flex items-center space-x-2 mt-2 text-xs text-gray-600">
                          <Calendar className="w-3 h-3" />
                          <span>{formatDate(entry.createdAt)}</span>
                        </div>
                      </div>
                      <button
                        onClick={(e) => {
                          e.stopPropagation();
                          deleteEntry(entry.id);
                        }}
                        className="p-1 text-gray-600 hover:text-red-400 transition-colors"
                      >
                        <Trash2 className="w-4 h-4" />
                      </button>
                    </div>
                  </div>
                ))
              ) : (
                <div className="text-center py-8">
                  <BookOpen className="w-12 h-12 text-gray-600 mx-auto mb-3" />
                  <p className="text-gray-500">No entries yet</p>
                </div>
              )}
            </div>
          </div>

          {/* Editor */}
          <div className="lg:col-span-2">
            {selectedEntry ? (
              <div className="bg-white/5 border border-gold/10 rounded-2xl overflow-hidden h-full">
                {/* Editor Header */}
                <div className="p-4 border-b border-gold/10 flex items-center justify-between">
                  <input
                    type="text"
                    value={editTitle}
                    onChange={(e) => {
                      setEditTitle(e.target.value);
                      setSaveStatus('unsaved');
                    }}
                    className="bg-transparent text-white text-xl font-semibold focus:outline-none flex-1"
                    placeholder="Entry title..."
                  />
                  <div className="flex items-center space-x-3">
                    <span className={`text-xs ${
                      saveStatus === 'saved' ? 'text-green-400' :
                      saveStatus === 'saving' ? 'text-gold' :
                      'text-gray-500'
                    }`}>
                      {saveStatus === 'saved' ? 'Saved' :
                       saveStatus === 'saving' ? 'Saving...' :
                       'Unsaved changes'}
                    </span>
                    <button
                      onClick={() => setShowPrompts(!showPrompts)}
                      className="px-3 py-1 bg-gold/20 text-gold rounded-lg text-sm hover:bg-gold/30 transition-colors"
                    >
                      Prompts
                    </button>
                  </div>
                </div>

                {/* Prompts Dropdown */}
                {showPrompts && (
                  <div className="p-4 border-b border-gold/10 bg-gold/5">
                    <p className="text-gray-400 text-sm mb-3">Click a prompt to add it to your entry:</p>
                    <div className="flex flex-wrap gap-2">
                      {JOURNAL_PROMPTS.map((prompt, idx) => (
                        <button
                          key={idx}
                          onClick={() => insertPrompt(prompt)}
                          className="px-3 py-1 bg-white/5 border border-gold/20 text-gray-300 rounded-lg text-xs hover:bg-white/10 hover:border-gold/40 transition-colors"
                        >
                          {prompt.slice(0, 40)}...
                        </button>
                      ))}
                    </div>
                  </div>
                )}

                {/* Editor Content */}
                <div className="p-6">
                  <textarea
                    value={editContent}
                    onChange={(e) => {
                      setEditContent(e.target.value);
                      setSaveStatus('unsaved');
                    }}
                    placeholder="Begin writing your reflection..."
                    className="w-full h-[400px] bg-transparent text-gray-300 leading-relaxed resize-none focus:outline-none placeholder-gray-600"
                  />
                </div>

                {/* Editor Footer */}
                <div className="p-4 border-t border-gold/10 flex items-center justify-between text-sm text-gray-500">
                  <span>Last updated: {formatDate(selectedEntry.updatedAt)}</span>
                  <span>{editContent.split(/\s+/).filter(Boolean).length} words</span>
                </div>
              </div>
            ) : (
              <div className="bg-white/5 border border-gold/10 rounded-2xl h-full flex items-center justify-center p-12">
                <div className="text-center">
                  <BookOpen className="w-16 h-16 text-gray-600 mx-auto mb-4" />
                  <h3 className="text-white font-semibold mb-2">Select an entry or create a new one</h3>
                  <p className="text-gray-500 mb-6">Your journal is a safe space for reflection and growth.</p>
                  <button
                    onClick={createNewEntry}
                    className="flex items-center space-x-2 px-6 py-3 bg-gradient-to-r from-crimson to-gold text-white rounded-xl font-medium hover:opacity-90 transition-opacity mx-auto"
                  >
                    <Plus className="w-5 h-5" />
                    <span>Create Entry</span>
                  </button>
                </div>
              </div>
            )}
          </div>
        </div>
      </div>
    </section>
  );
};

export default JournalSection;
