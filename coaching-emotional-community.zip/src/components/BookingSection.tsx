import React, { useState, useEffect } from 'react';
import { Calendar, Clock, Video, ExternalLink, ChevronRight, User, Star, CheckCircle } from 'lucide-react';
import { supabase } from '@/lib/supabase';
import { IMAGES } from '@/lib/constants';

interface BookingSectionProps {
  isLoggedIn: boolean;
  setShowAuthModal: (show: boolean) => void;
}

const SESSION_TYPES = [
  {
    id: 'discovery',
    name: 'Discovery Call',
    duration: 30,
    price: 0,
    description: 'A free introductory call to explore if we\'re a good fit for working together.',
    features: ['Get to know each other', 'Discuss your goals', 'Explore coaching options']
  },
  {
    id: 'single',
    name: 'Single Session',
    duration: 60,
    price: 197,
    description: 'A focused 1:1 coaching session to work through a specific challenge or pattern.',
    features: ['Deep pattern exploration', 'Personalized guidance', 'Action steps & resources']
  },
  {
    id: 'intensive',
    name: 'Transformation Intensive',
    duration: 90,
    price: 347,
    description: 'An extended session for deeper work on complex emotional patterns.',
    features: ['Extended exploration time', 'Somatic techniques', 'Follow-up support', 'Recording provided']
  }
];

const BookingSection: React.FC<BookingSectionProps> = ({ isLoggedIn, setShowAuthModal }) => {
  const [selectedSession, setSelectedSession] = useState<string | null>(null);
  const [showCalendly, setShowCalendly] = useState(false);
  const [upcomingSessions, setUpcomingSessions] = useState<any[]>([]);
  const [loading, setLoading] = useState(false);

  const handleBookSession = async (sessionId: string) => {
    if (!isLoggedIn) {
      setShowAuthModal(true);
      return;
    }

    setSelectedSession(sessionId);
    setShowCalendly(true);

    // Try to fetch Calendly event types
    try {
      const { data, error } = await supabase.functions.invoke('calendly-events', {
        body: { action: 'get-event-types' }
      });
      
      if (data?.collection) {
        console.log('Calendly event types:', data.collection);
      }
    } catch (error) {
      console.log('Calendly integration pending setup');
    }
  };

  const addToCalendar = (type: 'google' | 'outlook' | 'apple') => {
    const event = {
      title: 'Coaching Session - The Emotional Alchemist',
      start: new Date(Date.now() + 7 * 24 * 60 * 60 * 1000).toISOString(),
      duration: 60
    };

    let url = '';
    if (type === 'google') {
      url = `https://calendar.google.com/calendar/render?action=TEMPLATE&text=${encodeURIComponent(event.title)}&dates=${event.start.replace(/[-:]/g, '').split('.')[0]}Z/${event.start.replace(/[-:]/g, '').split('.')[0]}Z`;
    }
    
    if (url) {
      window.open(url, '_blank');
    }
  };

  return (
    <section className="py-20 px-4 sm:px-6 lg:px-8 bg-charcoal min-h-screen">
      <div className="max-w-6xl mx-auto">
        {/* Header */}
        <div className="text-center mb-16">
          <h2 className="text-3xl sm:text-4xl font-serif text-white mb-4">
            Book Your <span className="text-transparent bg-clip-text bg-gradient-to-r from-crimson to-gold">Transformation</span>
          </h2>
          <p className="text-gray-400 max-w-2xl mx-auto">
            Work directly with your coach in a safe, confidential space designed for deep healing and growth.
          </p>
        </div>

        {/* Coach Profile */}
        <div className="mb-16 p-8 bg-gradient-to-r from-crimson/10 to-gold/10 border border-gold/20 rounded-2xl">
          <div className="flex flex-col md:flex-row items-center md:items-start gap-8">
            <img
              src={IMAGES.coach}
              alt="Coach"
              className="w-32 h-32 rounded-full object-cover border-4 border-gold/30"
            />
            <div className="flex-1 text-center md:text-left">
              <h3 className="text-2xl font-serif text-white mb-2">The Emotional Alchemist</h3>
              <p className="text-gold mb-4">Certified Trauma-Informed Coach & Somatic Practitioner</p>
              <p className="text-gray-400 mb-4 max-w-2xl">
                With over 10 years of experience guiding individuals through emotional transformation, 
                I specialize in helping you move from survival mode to sovereignty. My approach combines 
                neuroscience, somatic practices, and deep emotional work.
              </p>
              <div className="flex flex-wrap items-center justify-center md:justify-start gap-4 text-sm">
                <div className="flex items-center space-x-1 text-gold">
                  <Star className="w-4 h-4 fill-current" />
                  <span>4.9/5 rating</span>
                </div>
                <div className="flex items-center space-x-1 text-gray-400">
                  <User className="w-4 h-4" />
                  <span>500+ clients</span>
                </div>
                <div className="flex items-center space-x-1 text-gray-400">
                  <CheckCircle className="w-4 h-4" />
                  <span>ICF Certified</span>
                </div>
              </div>
            </div>
          </div>
        </div>

        {/* Session Types */}
        <div className="grid grid-cols-1 md:grid-cols-3 gap-6 mb-16">
          {SESSION_TYPES.map((session) => (
            <div
              key={session.id}
              className={`p-6 bg-white/5 border rounded-2xl transition-all duration-300 cursor-pointer ${
                selectedSession === session.id 
                  ? 'border-gold shadow-lg shadow-gold/10' 
                  : 'border-gold/10 hover:border-gold/30'
              }`}
              onClick={() => setSelectedSession(session.id)}
            >
              {/* Price */}
              <div className="flex items-baseline justify-between mb-4">
                <span className="text-3xl font-bold text-gold">
                  {session.price === 0 ? 'Free' : `$${session.price}`}
                </span>
                <span className="text-gray-500 text-sm">{session.duration} min</span>
              </div>

              {/* Title */}
              <h3 className="text-xl font-semibold text-white mb-2">{session.name}</h3>
              <p className="text-gray-400 text-sm mb-4">{session.description}</p>

              {/* Features */}
              <ul className="space-y-2 mb-6">
                {session.features.map((feature, idx) => (
                  <li key={idx} className="flex items-center space-x-2 text-sm text-gray-300">
                    <CheckCircle className="w-4 h-4 text-gold flex-shrink-0" />
                    <span>{feature}</span>
                  </li>
                ))}
              </ul>

              {/* Book Button */}
              <button
                onClick={(e) => {
                  e.stopPropagation();
                  handleBookSession(session.id);
                }}
                className="w-full py-3 bg-gradient-to-r from-crimson to-gold text-white rounded-xl font-medium hover:opacity-90 transition-opacity flex items-center justify-center space-x-2"
              >
                <Calendar className="w-5 h-5" />
                <span>Book Now</span>
              </button>
            </div>
          ))}
        </div>

        {/* Calendly Embed Modal */}
        {showCalendly && (
          <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/80">
            <div className="w-full max-w-3xl bg-charcoal border border-gold/20 rounded-2xl overflow-hidden">
              <div className="flex items-center justify-between p-4 border-b border-gold/20">
                <h3 className="text-white font-semibold">Select a Time</h3>
                <button
                  onClick={() => setShowCalendly(false)}
                  className="p-2 text-gray-400 hover:text-white hover:bg-white/5 rounded-lg transition-colors"
                >
                  <svg className="w-5 h-5" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                    <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M6 18L18 6M6 6l12 12" />
                  </svg>
                </button>
              </div>
              <div className="p-8 text-center">
                <Calendar className="w-16 h-16 text-gold mx-auto mb-4" />
                <p className="text-gray-400 mb-6">
                  Calendly integration is ready! Connect your Calendly account to enable booking.
                </p>
                <div className="flex flex-col sm:flex-row items-center justify-center gap-4">
                  <a
                    href="https://calendly.com"
                    target="_blank"
                    rel="noopener noreferrer"
                    className="flex items-center space-x-2 px-6 py-3 bg-gradient-to-r from-crimson to-gold text-white rounded-xl font-medium hover:opacity-90 transition-opacity"
                  >
                    <span>Open Calendly</span>
                    <ExternalLink className="w-4 h-4" />
                  </a>
                  <button
                    onClick={() => setShowCalendly(false)}
                    className="px-6 py-3 bg-white/5 border border-gold/20 text-white rounded-xl font-medium hover:bg-white/10 transition-colors"
                  >
                    Cancel
                  </button>
                </div>
              </div>
            </div>
          </div>
        )}

        {/* My Sessions (if logged in) */}
        {isLoggedIn && (
          <div className="mt-16">
            <h3 className="text-2xl font-serif text-white mb-6">My Upcoming Sessions</h3>
            <div className="bg-white/5 border border-gold/10 rounded-2xl p-8 text-center">
              <Calendar className="w-12 h-12 text-gray-600 mx-auto mb-4" />
              <p className="text-gray-400 mb-4">No upcoming sessions scheduled.</p>
              <button
                onClick={() => handleBookSession('discovery')}
                className="text-gold hover:underline"
              >
                Book your first session
              </button>
            </div>
          </div>
        )}

        {/* FAQ */}
        <div className="mt-16">
          <h3 className="text-2xl font-serif text-white mb-6 text-center">Frequently Asked Questions</h3>
          <div className="space-y-4 max-w-3xl mx-auto">
            {[
              {
                q: 'What happens in a coaching session?',
                a: 'Each session is tailored to your needs. We\'ll explore your current challenges, identify patterns, and work through them using a combination of dialogue, somatic techniques, and practical tools.'
              },
              {
                q: 'Is coaching the same as therapy?',
                a: 'No, coaching is not therapy. While we work with emotions and patterns, coaching is forward-focused and action-oriented. If you need clinical support, I\'ll help you find appropriate resources.'
              },
              {
                q: 'How do I prepare for a session?',
                a: 'Come as you are. It helps to have a quiet, private space and perhaps a journal nearby. You\'ll receive preparation materials after booking.'
              }
            ].map((faq, idx) => (
              <div key={idx} className="p-6 bg-white/5 border border-gold/10 rounded-xl">
                <h4 className="text-white font-medium mb-2">{faq.q}</h4>
                <p className="text-gray-400 text-sm">{faq.a}</p>
              </div>
            ))}
          </div>
        </div>
      </div>
    </section>
  );
};

export default BookingSection;
