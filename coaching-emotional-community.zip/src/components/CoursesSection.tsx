import React, { useState } from 'react';
import { Search, Filter, Grid, List } from 'lucide-react';
import { COURSES } from '@/lib/constants';
import CourseCard from './CourseCard';

interface CoursesSectionProps {
  userTier: string;
  setCurrentView: (view: string) => void;
  setSelectedCourse: (courseId: string) => void;
}

const CoursesSection: React.FC<CoursesSectionProps> = ({ userTier, setCurrentView, setSelectedCourse }) => {
  const [searchQuery, setSearchQuery] = useState('');
  const [filterTier, setFilterTier] = useState<string>('all');
  const [viewMode, setViewMode] = useState<'grid' | 'list'>('grid');

  const filteredCourses = COURSES.filter(course => {
    const matchesSearch = course.title.toLowerCase().includes(searchQuery.toLowerCase()) ||
                         course.description.toLowerCase().includes(searchQuery.toLowerCase());
    const matchesTier = filterTier === 'all' || course.tier === filterTier;
    return matchesSearch && matchesTier;
  });

  const handleCourseSelect = (courseId: string) => {
    setSelectedCourse(courseId);
    setCurrentView('course-detail');
  };

  return (
    <section className="py-20 px-4 sm:px-6 lg:px-8 bg-charcoal min-h-screen">
      <div className="max-w-7xl mx-auto">
        {/* Header */}
        <div className="text-center mb-12">
          <h2 className="text-3xl sm:text-4xl font-serif text-white mb-4">
            Your <span className="text-transparent bg-clip-text bg-gradient-to-r from-crimson to-gold">Transformation</span> Library
          </h2>
          <p className="text-gray-400 max-w-2xl mx-auto">
            Explore our collection of courses designed to guide you from survival mode to sovereignty.
          </p>
        </div>

        {/* Filters */}
        <div className="flex flex-col sm:flex-row items-stretch sm:items-center justify-between gap-4 mb-8">
          {/* Search */}
          <div className="relative flex-1 max-w-md">
            <Search className="absolute left-4 top-1/2 transform -translate-y-1/2 w-5 h-5 text-gray-500" />
            <input
              type="text"
              placeholder="Search courses..."
              value={searchQuery}
              onChange={(e) => setSearchQuery(e.target.value)}
              className="w-full pl-12 pr-4 py-3 bg-white/5 border border-gold/20 rounded-xl text-white placeholder-gray-500 focus:outline-none focus:border-gold/50 transition-colors"
            />
          </div>

          <div className="flex items-center space-x-3">
            {/* Tier Filter */}
            <div className="relative">
              <Filter className="absolute left-3 top-1/2 transform -translate-y-1/2 w-4 h-4 text-gray-500" />
              <select
                value={filterTier}
                onChange={(e) => setFilterTier(e.target.value)}
                className="pl-10 pr-8 py-3 bg-white/5 border border-gold/20 rounded-xl text-white appearance-none cursor-pointer focus:outline-none focus:border-gold/50 transition-colors"
              >
                <option value="all" className="bg-charcoal">All Tiers</option>
                <option value="free" className="bg-charcoal">Free</option>
                <option value="paid" className="bg-charcoal">Alchemist</option>
                <option value="vip" className="bg-charcoal">Sovereign</option>
              </select>
            </div>

            {/* View Toggle */}
            <div className="flex items-center bg-white/5 border border-gold/20 rounded-xl p-1">
              <button
                onClick={() => setViewMode('grid')}
                className={`p-2 rounded-lg transition-colors ${viewMode === 'grid' ? 'bg-gold/20 text-gold' : 'text-gray-500 hover:text-white'}`}
              >
                <Grid className="w-5 h-5" />
              </button>
              <button
                onClick={() => setViewMode('list')}
                className={`p-2 rounded-lg transition-colors ${viewMode === 'list' ? 'bg-gold/20 text-gold' : 'text-gray-500 hover:text-white'}`}
              >
                <List className="w-5 h-5" />
              </button>
            </div>
          </div>
        </div>

        {/* Course Grid */}
        {filteredCourses.length > 0 ? (
          <div className={viewMode === 'grid' 
            ? 'grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-6' 
            : 'space-y-4'
          }>
            {filteredCourses.map((course) => (
              viewMode === 'grid' ? (
                <CourseCard
                  key={course.id}
                  course={course}
                  userTier={userTier}
                  onSelect={handleCourseSelect}
                />
              ) : (
                <div
                  key={course.id}
                  onClick={() => handleCourseSelect(course.id)}
                  className="flex items-center space-x-4 p-4 bg-white/5 border border-gold/10 rounded-xl cursor-pointer hover:border-gold/30 transition-all"
                >
                  <img
                    src={course.thumbnail}
                    alt={course.title}
                    className="w-24 h-24 object-cover rounded-lg"
                  />
                  <div className="flex-1">
                    <h3 className="text-white font-semibold mb-1">{course.title}</h3>
                    <p className="text-gray-400 text-sm line-clamp-1">{course.description}</p>
                    <div className="flex items-center space-x-4 mt-2 text-sm text-gray-500">
                      <span>{course.duration} min</span>
                      <span>{course.lessons} lessons</span>
                      <span className={`px-2 py-0.5 rounded-full text-xs ${
                        course.tier === 'free' ? 'bg-green-500/20 text-green-400' :
                        course.tier === 'paid' ? 'bg-gold/20 text-gold' :
                        'bg-crimson/20 text-crimson'
                      }`}>
                        {course.tier === 'free' ? 'Free' : course.tier === 'paid' ? 'Alchemist' : 'Sovereign'}
                      </span>
                    </div>
                  </div>
                </div>
              )
            ))}
          </div>
        ) : (
          <div className="text-center py-16">
            <p className="text-gray-400">No courses found matching your criteria.</p>
          </div>
        )}

        {/* Upgrade CTA */}
        {userTier === 'free' && (
          <div className="mt-16 p-8 bg-gradient-to-r from-crimson/10 to-gold/10 border border-gold/20 rounded-2xl text-center">
            <h3 className="text-2xl font-serif text-white mb-3">Unlock Your Full Potential</h3>
            <p className="text-gray-400 mb-6 max-w-lg mx-auto">
              Upgrade to Alchemist or Sovereign tier to access our complete library of transformative courses.
            </p>
            <button
              onClick={() => setCurrentView('pricing')}
              className="px-8 py-3 bg-gradient-to-r from-crimson to-gold text-white rounded-xl font-semibold hover:opacity-90 transition-opacity"
            >
              View Membership Options
            </button>
          </div>
        )}
      </div>
    </section>
  );
};

export default CoursesSection;
