import React from 'react';
import { BookOpen, Users, MessageCircle, Calendar, ShoppingBag, Shield, Sparkles, Heart } from 'lucide-react';

interface FeaturesSectionProps {
  setCurrentView: (view: string) => void;
}

const FeaturesSection: React.FC<FeaturesSectionProps> = ({ setCurrentView }) => {
  const features = [
    {
      icon: <BookOpen className="w-6 h-6" />,
      title: 'Transformative Courses',
      description: 'Expert-led courses on emotional regulation, nervous system mastery, and inner healing.',
      color: 'from-crimson to-crimson/50',
      view: 'courses'
    },
    {
      icon: <MessageCircle className="w-6 h-6" />,
      title: '24/7 AI Guide',
      description: 'Your personal Emotional Alchemist assistant, available whenever you need support.',
      color: 'from-gold to-gold/50',
      view: 'home'
    },
    {
      icon: <Users className="w-6 h-6" />,
      title: 'Sanctuary Community',
      description: 'Connect with fellow seekers in a safe, supportive space for growth and sharing.',
      color: 'from-purple-500 to-purple-500/50',
      view: 'community'
    },
    {
      icon: <Calendar className="w-6 h-6" />,
      title: '1:1 Coaching',
      description: 'Book personalized sessions for deeper work on your unique transformation journey.',
      color: 'from-green-500 to-green-500/50',
      view: 'booking'
    },
    {
      icon: <ShoppingBag className="w-6 h-6" />,
      title: 'Resource Library',
      description: 'Access premium PDFs, meditations, and tools to support your daily practice.',
      color: 'from-blue-500 to-blue-500/50',
      view: 'store'
    },
    {
      icon: <Heart className="w-6 h-6" />,
      title: 'Private Journaling',
      description: 'A secure space for reflection with guided prompts and auto-save functionality.',
      color: 'from-pink-500 to-pink-500/50',
      view: 'journal'
    }
  ];

  return (
    <section className="py-24 px-4 sm:px-6 lg:px-8 bg-gradient-to-b from-charcoal to-charcoal/95">
      <div className="max-w-7xl mx-auto">
        {/* Header */}
        <div className="text-center mb-16">
          <div className="inline-flex items-center space-x-2 px-4 py-2 bg-gold/10 border border-gold/30 rounded-full mb-6">
            <Sparkles className="w-4 h-4 text-gold" />
            <span className="text-gold text-sm font-medium">Your Complete Transformation Toolkit</span>
          </div>
          <h2 className="text-3xl sm:text-4xl md:text-5xl font-serif text-white mb-6">
            Everything You Need to{' '}
            <span className="text-transparent bg-clip-text bg-gradient-to-r from-crimson to-gold">
              Alchemize
            </span>
          </h2>
          <p className="text-gray-400 max-w-2xl mx-auto text-lg">
            A comprehensive ecosystem designed to support every aspect of your emotional transformation journey.
          </p>
        </div>

        {/* Features Grid */}
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
          {features.map((feature, index) => (
            <div
              key={index}
              onClick={() => setCurrentView(feature.view)}
              className="group p-8 bg-white/5 border border-gold/10 rounded-2xl cursor-pointer transition-all duration-300 hover:border-gold/30 hover:shadow-xl hover:shadow-gold/5 hover:-translate-y-1"
            >
              <div className={`w-14 h-14 rounded-xl bg-gradient-to-br ${feature.color} bg-opacity-20 flex items-center justify-center mb-6 text-white group-hover:scale-110 transition-transform`}>
                {feature.icon}
              </div>
              <h3 className="text-xl font-semibold text-white mb-3 group-hover:text-gold transition-colors">
                {feature.title}
              </h3>
              <p className="text-gray-400 leading-relaxed">
                {feature.description}
              </p>
            </div>
          ))}
        </div>

        {/* Safety Banner */}
        <div className="mt-16 p-8 bg-gradient-to-r from-crimson/10 to-gold/10 border border-gold/20 rounded-2xl">
          <div className="flex flex-col md:flex-row items-center justify-between gap-6">
            <div className="flex items-center space-x-4">
              <div className="w-14 h-14 bg-gold/20 rounded-xl flex items-center justify-center">
                <Shield className="w-7 h-7 text-gold" />
              </div>
              <div>
                <h3 className="text-white font-semibold text-lg">Your Safety is Our Priority</h3>
                <p className="text-gray-400 text-sm">
                  End-to-end encryption for journals, crisis detection in AI, and trauma-informed design throughout.
                </p>
              </div>
            </div>
            <button
              onClick={() => setCurrentView('pricing')}
              className="px-8 py-3 bg-gradient-to-r from-crimson to-gold text-white rounded-xl font-semibold hover:opacity-90 transition-opacity whitespace-nowrap"
            >
              Start Your Journey
            </button>
          </div>
        </div>
      </div>
    </section>
  );
};

export default FeaturesSection;
