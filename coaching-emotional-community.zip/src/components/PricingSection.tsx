import React, { useState } from 'react';
import { Check, Sparkles, Crown, Star } from 'lucide-react';
import { TIERS } from '@/lib/constants';
import { supabase } from '@/lib/supabase';

interface PricingSectionProps {
  isLoggedIn: boolean;
  userTier: string;
  setShowAuthModal: (show: boolean) => void;
}

const PricingSection: React.FC<PricingSectionProps> = ({ isLoggedIn, userTier, setShowAuthModal }) => {
  const [billingCycle, setBillingCycle] = useState<'monthly' | 'yearly'>('monthly');
  const [isProcessing, setIsProcessing] = useState(false);

  const getTierIcon = (tier: string) => {
    switch (tier) {
      case 'free':
        return <Star className="w-6 h-6" />;
      case 'paid':
        return <Sparkles className="w-6 h-6" />;
      case 'vip':
        return <Crown className="w-6 h-6" />;
      default:
        return <Star className="w-6 h-6" />;
    }
  };

  const getPrice = (tier: string) => {
    const basePrice = TIERS[tier as keyof typeof TIERS].price;
    if (billingCycle === 'yearly') {
      return Math.round(basePrice * 10); // 2 months free
    }
    return basePrice;
  };

  const handleSubscribe = async (tier: string) => {
    if (!isLoggedIn) {
      setShowAuthModal(true);
      return;
    }

    if (tier === 'free') return;

    setIsProcessing(true);

    try {
      const price = getPrice(tier);
      const { data, error } = await supabase.functions.invoke('create-checkout', {
        body: {
          productId: `tier-${tier}`,
          productName: `${TIERS[tier as keyof typeof TIERS].name} Membership`,
          priceInCents: price * 100,
          successUrl: window.location.origin + '?success=true',
          cancelUrl: window.location.origin + '?canceled=true',
          mode: 'subscription'
        }
      });

      if (error) throw error;

      if (data?.url) {
        window.location.href = data.url;
      }
    } catch (error) {
      console.error('Subscription error:', error);
      alert('Subscription initiated! (Demo mode)');
    } finally {
      setIsProcessing(false);
    }
  };

  return (
    <section className="py-20 px-4 sm:px-6 lg:px-8 bg-charcoal min-h-screen">
      <div className="max-w-6xl mx-auto">
        {/* Header */}
        <div className="text-center mb-12">
          <h2 className="text-3xl sm:text-4xl font-serif text-white mb-4">
            Choose Your <span className="text-transparent bg-clip-text bg-gradient-to-r from-crimson to-gold">Path</span>
          </h2>
          <p className="text-gray-400 max-w-2xl mx-auto mb-8">
            Select the membership tier that aligns with your transformation journey.
          </p>

          {/* Billing Toggle */}
          <div className="inline-flex items-center p-1 bg-white/5 border border-gold/20 rounded-xl">
            <button
              onClick={() => setBillingCycle('monthly')}
              className={`px-6 py-2 rounded-lg text-sm font-medium transition-all ${
                billingCycle === 'monthly'
                  ? 'bg-gradient-to-r from-crimson to-gold text-white'
                  : 'text-gray-400 hover:text-white'
              }`}
            >
              Monthly
            </button>
            <button
              onClick={() => setBillingCycle('yearly')}
              className={`px-6 py-2 rounded-lg text-sm font-medium transition-all ${
                billingCycle === 'yearly'
                  ? 'bg-gradient-to-r from-crimson to-gold text-white'
                  : 'text-gray-400 hover:text-white'
              }`}
            >
              Yearly
              <span className="ml-2 text-xs text-gold">Save 17%</span>
            </button>
          </div>
        </div>

        {/* Pricing Cards */}
        <div className="grid grid-cols-1 md:grid-cols-3 gap-8">
          {Object.entries(TIERS).map(([key, tier]) => {
            const isCurrentTier = userTier === key;
            const isPopular = key === 'paid';
            const price = getPrice(key);

            return (
              <div
                key={key}
                className={`relative p-8 rounded-2xl transition-all duration-300 ${
                  isPopular
                    ? 'bg-gradient-to-b from-gold/10 to-crimson/10 border-2 border-gold shadow-xl shadow-gold/10 scale-105'
                    : 'bg-white/5 border border-gold/10 hover:border-gold/30'
                }`}
              >
                {/* Popular Badge */}
                {isPopular && (
                  <div className="absolute -top-4 left-1/2 transform -translate-x-1/2">
                    <span className="px-4 py-1 bg-gradient-to-r from-crimson to-gold text-white text-sm font-medium rounded-full">
                      Most Popular
                    </span>
                  </div>
                )}

                {/* Current Tier Badge */}
                {isCurrentTier && (
                  <div className="absolute -top-4 right-4">
                    <span className="px-3 py-1 bg-green-500/20 text-green-400 text-xs font-medium rounded-full border border-green-500/30">
                      Current Plan
                    </span>
                  </div>
                )}

                {/* Icon */}
                <div className={`w-14 h-14 rounded-xl flex items-center justify-center mb-6 ${
                  key === 'free' ? 'bg-gray-500/20 text-gray-400' :
                  key === 'paid' ? 'bg-gold/20 text-gold' :
                  'bg-crimson/20 text-crimson'
                }`}>
                  {getTierIcon(key)}
                </div>

                {/* Tier Name */}
                <h3 className="text-2xl font-serif text-white mb-2">{tier.name}</h3>

                {/* Price */}
                <div className="mb-6">
                  <span className="text-4xl font-bold text-white">
                    {price === 0 ? 'Free' : `$${price}`}
                  </span>
                  {price > 0 && (
                    <span className="text-gray-500 ml-2">
                      /{billingCycle === 'monthly' ? 'month' : 'year'}
                    </span>
                  )}
                </div>

                {/* Features */}
                <ul className="space-y-3 mb-8">
                  {tier.features.map((feature, idx) => (
                    <li key={idx} className="flex items-start space-x-3">
                      <Check className={`w-5 h-5 flex-shrink-0 ${
                        key === 'free' ? 'text-gray-500' :
                        key === 'paid' ? 'text-gold' :
                        'text-crimson'
                      }`} />
                      <span className="text-gray-300 text-sm">{feature}</span>
                    </li>
                  ))}
                </ul>

                {/* CTA Button */}
                <button
                  onClick={() => handleSubscribe(key)}
                  disabled={isCurrentTier || isProcessing}
                  className={`w-full py-3 rounded-xl font-semibold transition-all ${
                    isCurrentTier
                      ? 'bg-gray-500/20 text-gray-500 cursor-not-allowed'
                      : key === 'free'
                        ? 'bg-white/10 text-white hover:bg-white/20'
                        : 'bg-gradient-to-r from-crimson to-gold text-white hover:opacity-90'
                  }`}
                >
                  {isCurrentTier 
                    ? 'Current Plan' 
                    : key === 'free' 
                      ? 'Get Started' 
                      : isProcessing 
                        ? 'Processing...' 
                        : 'Subscribe Now'}
                </button>
              </div>
            );
          })}
        </div>

        {/* Guarantee */}
        <div className="mt-16 text-center">
          <div className="inline-flex items-center space-x-3 px-6 py-3 bg-white/5 border border-gold/20 rounded-full">
            <svg className="w-6 h-6 text-gold" fill="none" stroke="currentColor" viewBox="0 0 24 24">
              <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M9 12l2 2 4-4m5.618-4.016A11.955 11.955 0 0112 2.944a11.955 11.955 0 01-8.618 3.04A12.02 12.02 0 003 9c0 5.591 3.824 10.29 9 11.622 5.176-1.332 9-6.03 9-11.622 0-1.042-.133-2.052-.382-3.016z" />
            </svg>
            <span className="text-gray-300">30-day money-back guarantee. Cancel anytime.</span>
          </div>
        </div>

        {/* FAQ */}
        <div className="mt-16">
          <h3 className="text-2xl font-serif text-white mb-8 text-center">Common Questions</h3>
          <div className="grid grid-cols-1 md:grid-cols-2 gap-6 max-w-4xl mx-auto">
            {[
              {
                q: 'Can I upgrade or downgrade anytime?',
                a: 'Yes! You can change your plan at any time. Upgrades take effect immediately, and downgrades apply at the end of your billing cycle.'
              },
              {
                q: 'What payment methods do you accept?',
                a: 'We accept all major credit cards through Stripe. Your payment information is securely processed and never stored on our servers.'
              },
              {
                q: 'Is there a free trial?',
                a: 'Our Free Seeker tier gives you access to introductory content. You can explore before committing to a paid membership.'
              },
              {
                q: 'What happens if I cancel?',
                a: 'You\'ll retain access until the end of your billing period. Your progress and journal entries are saved if you decide to return.'
              }
            ].map((faq, idx) => (
              <div key={idx} className="p-6 bg-white/5 border border-gold/10 rounded-xl">
                <h4 className="text-white font-medium mb-2">{faq.q}</h4>
                <p className="text-gray-400 text-sm">{faq.a}</p>
              </div>
            ))}
          </div>
        </div>
      </div>
    </section>
  );
};

export default PricingSection;
