import React, { useState } from 'react';
import { ShoppingBag, FileText, Headphones, Video, Download, Search, Filter, Check } from 'lucide-react';
import { PRODUCTS } from '@/lib/constants';
import { supabase } from '@/lib/supabase';

interface Product {
  id: string;
  title: string;
  description: string;
  price: number;
  thumbnail: string;
  type: string;
}

interface StoreSectionProps {
  isLoggedIn: boolean;
  purchasedProducts: Set<string>;
  setPurchasedProducts: (products: Set<string>) => void;
  setShowAuthModal: (show: boolean) => void;
}

const StoreSection: React.FC<StoreSectionProps> = ({ 
  isLoggedIn, 
  purchasedProducts, 
  setPurchasedProducts,
  setShowAuthModal 
}) => {
  const [searchQuery, setSearchQuery] = useState('');
  const [filterType, setFilterType] = useState<string>('all');
  const [cart, setCart] = useState<Set<string>>(new Set());
  const [isCheckingOut, setIsCheckingOut] = useState(false);

  const filteredProducts = PRODUCTS.filter(product => {
    const matchesSearch = product.title.toLowerCase().includes(searchQuery.toLowerCase()) ||
                         product.description.toLowerCase().includes(searchQuery.toLowerCase());
    const matchesType = filterType === 'all' || product.type === filterType;
    return matchesSearch && matchesType;
  });

  const getTypeIcon = (type: string) => {
    switch (type) {
      case 'pdf':
        return <FileText className="w-4 h-4" />;
      case 'audio':
        return <Headphones className="w-4 h-4" />;
      case 'video':
        return <Video className="w-4 h-4" />;
      default:
        return <FileText className="w-4 h-4" />;
    }
  };

  const addToCart = (productId: string) => {
    if (!isLoggedIn) {
      setShowAuthModal(true);
      return;
    }
    setCart(prev => {
      const newCart = new Set(prev);
      if (newCart.has(productId)) {
        newCart.delete(productId);
      } else {
        newCart.add(productId);
      }
      return newCart;
    });
  };

  const handleCheckout = async (productId: string) => {
    if (!isLoggedIn) {
      setShowAuthModal(true);
      return;
    }

    setIsCheckingOut(true);
    const product = PRODUCTS.find(p => p.id === productId);
    if (!product) return;

    try {
      const { data, error } = await supabase.functions.invoke('create-checkout', {
        body: {
          productId: product.id,
          productName: product.title,
          priceInCents: product.price * 100,
          successUrl: window.location.origin + '?success=true',
          cancelUrl: window.location.origin + '?canceled=true',
          mode: 'payment'
        }
      });

      if (error) throw error;

      if (data?.url) {
        window.location.href = data.url;
      }
    } catch (error) {
      console.error('Checkout error:', error);
      // For demo, simulate purchase
      setPurchasedProducts(new Set([...purchasedProducts, productId]));
      alert('Product purchased successfully! (Demo mode)');
    } finally {
      setIsCheckingOut(false);
    }
  };

  const cartTotal = Array.from(cart).reduce((total, productId) => {
    const product = PRODUCTS.find(p => p.id === productId);
    return total + (product?.price || 0);
  }, 0);

  return (
    <section className="py-20 px-4 sm:px-6 lg:px-8 bg-charcoal min-h-screen">
      <div className="max-w-7xl mx-auto">
        {/* Header */}
        <div className="text-center mb-12">
          <h2 className="text-3xl sm:text-4xl font-serif text-white mb-4">
            The <span className="text-transparent bg-clip-text bg-gradient-to-r from-crimson to-gold">Alchemist's</span> Store
          </h2>
          <p className="text-gray-400 max-w-2xl mx-auto">
            Premium resources to support your transformation journey.
          </p>
        </div>

        {/* Filters & Cart */}
        <div className="flex flex-col sm:flex-row items-stretch sm:items-center justify-between gap-4 mb-8">
          {/* Search */}
          <div className="relative flex-1 max-w-md">
            <Search className="absolute left-4 top-1/2 transform -translate-y-1/2 w-5 h-5 text-gray-500" />
            <input
              type="text"
              placeholder="Search products..."
              value={searchQuery}
              onChange={(e) => setSearchQuery(e.target.value)}
              className="w-full pl-12 pr-4 py-3 bg-white/5 border border-gold/20 rounded-xl text-white placeholder-gray-500 focus:outline-none focus:border-gold/50 transition-colors"
            />
          </div>

          <div className="flex items-center space-x-3">
            {/* Type Filter */}
            <div className="relative">
              <Filter className="absolute left-3 top-1/2 transform -translate-y-1/2 w-4 h-4 text-gray-500" />
              <select
                value={filterType}
                onChange={(e) => setFilterType(e.target.value)}
                className="pl-10 pr-8 py-3 bg-white/5 border border-gold/20 rounded-xl text-white appearance-none cursor-pointer focus:outline-none focus:border-gold/50 transition-colors"
              >
                <option value="all" className="bg-charcoal">All Types</option>
                <option value="pdf" className="bg-charcoal">PDFs</option>
                <option value="audio" className="bg-charcoal">Audio</option>
                <option value="video" className="bg-charcoal">Video</option>
              </select>
            </div>

            {/* Cart indicator */}
            {cart.size > 0 && (
              <div className="flex items-center space-x-2 px-4 py-3 bg-gold/10 border border-gold/30 rounded-xl">
                <ShoppingBag className="w-5 h-5 text-gold" />
                <span className="text-gold font-medium">{cart.size} items</span>
                <span className="text-white font-semibold">${cartTotal}</span>
              </div>
            )}
          </div>
        </div>

        {/* Products Grid */}
        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-6">
          {filteredProducts.map((product) => {
            const isPurchased = purchasedProducts.has(product.id);
            const isInCart = cart.has(product.id);

            return (
              <div
                key={product.id}
                className="group bg-white/5 border border-gold/10 rounded-2xl overflow-hidden transition-all duration-300 hover:border-gold/30 hover:shadow-xl hover:shadow-gold/5"
              >
                {/* Thumbnail */}
                <div className="relative aspect-square overflow-hidden">
                  <img
                    src={product.thumbnail}
                    alt={product.title}
                    className="w-full h-full object-cover transition-transform duration-500 group-hover:scale-110"
                  />
                  <div className="absolute inset-0 bg-gradient-to-t from-charcoal via-transparent to-transparent" />
                  
                  {/* Type badge */}
                  <div className="absolute top-3 left-3 flex items-center space-x-1 px-2 py-1 bg-charcoal/80 rounded-full text-xs text-gray-300">
                    {getTypeIcon(product.type)}
                    <span className="uppercase">{product.type}</span>
                  </div>

                  {/* Purchased badge */}
                  {isPurchased && (
                    <div className="absolute top-3 right-3 flex items-center space-x-1 px-2 py-1 bg-green-500/80 rounded-full text-xs text-white">
                      <Check className="w-3 h-3" />
                      <span>Owned</span>
                    </div>
                  )}
                </div>

                {/* Content */}
                <div className="p-5">
                  <h3 className="text-white font-semibold text-lg mb-2 group-hover:text-gold transition-colors">
                    {product.title}
                  </h3>
                  <p className="text-gray-400 text-sm mb-4 line-clamp-2">
                    {product.description}
                  </p>

                  {/* Price & Actions */}
                  <div className="flex items-center justify-between">
                    <span className="text-2xl font-bold text-gold">${product.price}</span>
                    
                    {isPurchased ? (
                      <button className="flex items-center space-x-2 px-4 py-2 bg-green-500/20 text-green-400 rounded-xl font-medium text-sm">
                        <Download className="w-4 h-4" />
                        <span>Download</span>
                      </button>
                    ) : (
                      <div className="flex items-center space-x-2">
                        <button
                          onClick={() => addToCart(product.id)}
                          className={`p-2 rounded-xl transition-colors ${
                            isInCart 
                              ? 'bg-gold/20 text-gold' 
                              : 'bg-white/5 text-gray-400 hover:text-gold hover:bg-gold/10'
                          }`}
                        >
                          <ShoppingBag className="w-5 h-5" />
                        </button>
                        <button
                          onClick={() => handleCheckout(product.id)}
                          disabled={isCheckingOut}
                          className="px-4 py-2 bg-gradient-to-r from-crimson to-gold text-white rounded-xl font-medium text-sm hover:opacity-90 transition-opacity disabled:opacity-50"
                        >
                          {isCheckingOut ? 'Processing...' : 'Buy Now'}
                        </button>
                      </div>
                    )}
                  </div>
                </div>
              </div>
            );
          })}
        </div>

        {/* Empty State */}
        {filteredProducts.length === 0 && (
          <div className="text-center py-16">
            <ShoppingBag className="w-12 h-12 text-gray-600 mx-auto mb-4" />
            <p className="text-gray-400">No products found matching your criteria.</p>
          </div>
        )}
      </div>
    </section>
  );
};

export default StoreSection;
