import React from 'react';
import { BookOpen, Calendar, Trophy, Clock, ArrowRight, Play, FileText, Sparkles } from 'lucide-react';
import { COURSES, IMAGES } from '@/lib/constants';

interface DashboardSectionProps {
  userTier: string;
  userEmotion: string;
  setCurrentView: (view: string) => void;
  setSelectedCourse: (courseId: string) => void;
}

const DashboardSection: React.FC<DashboardSectionProps> = ({ 
  userTier, 
  userEmotion, 
  setCurrentView,
  setSelectedCourse 
}) => {
  // Simulated user data
  const userData = {
    name: 'Alchemist',
    coursesCompleted: 2,
    currentStreak: 7,
    totalMinutes: 340,
    nextLiveSession: new Date(Date.now() + 2 * 24 * 60 * 60 * 1000)
  };

  const inProgressCourse = COURSES[0]; // Simulated in-progress course

  const formatDate = (date: Date) => {
    return date.toLocaleDateString('en-US', { 
      weekday: 'long', 
      month: 'short', 
      day: 'numeric',
      hour: 'numeric',
      minute: '2-digit'
    });
  };

  return (
    <section className="py-20 px-4 sm:px-6 lg:px-8 bg-charcoal min-h-screen">
      <div className="max-w-7xl mx-auto">
        {/* Welcome Header */}
        <div className="mb-12">
          <h1 className="text-3xl sm:text-4xl font-serif text-white mb-2">
            Welcome back, <span className="text-transparent bg-clip-text bg-gradient-to-r from-crimson to-gold">{userData.name}</span>
          </h1>
          <p className="text-gray-400">
            {userEmotion 
              ? `Continue your journey of transforming ${userEmotion} into wisdom.`
              : 'Continue your transformation journey.'}
          </p>
        </div>

        {/* Stats Grid */}
        <div className="grid grid-cols-2 md:grid-cols-4 gap-4 mb-12">
          <div className="p-6 bg-white/5 border border-gold/10 rounded-2xl">
            <div className="w-10 h-10 bg-gold/20 rounded-xl flex items-center justify-center mb-3">
              <Trophy className="w-5 h-5 text-gold" />
            </div>
            <p className="text-2xl font-bold text-white">{userData.coursesCompleted}</p>
            <p className="text-gray-500 text-sm">Courses Completed</p>
          </div>
          <div className="p-6 bg-white/5 border border-gold/10 rounded-2xl">
            <div className="w-10 h-10 bg-crimson/20 rounded-xl flex items-center justify-center mb-3">
              <Sparkles className="w-5 h-5 text-crimson" />
            </div>
            <p className="text-2xl font-bold text-white">{userData.currentStreak}</p>
            <p className="text-gray-500 text-sm">Day Streak</p>
          </div>
          <div className="p-6 bg-white/5 border border-gold/10 rounded-2xl">
            <div className="w-10 h-10 bg-purple-500/20 rounded-xl flex items-center justify-center mb-3">
              <Clock className="w-5 h-5 text-purple-400" />
            </div>
            <p className="text-2xl font-bold text-white">{userData.totalMinutes}</p>
            <p className="text-gray-500 text-sm">Minutes Learned</p>
          </div>
          <div className="p-6 bg-white/5 border border-gold/10 rounded-2xl">
            <div className="w-10 h-10 bg-green-500/20 rounded-xl flex items-center justify-center mb-3">
              <BookOpen className="w-5 h-5 text-green-400" />
            </div>
            <p className="text-2xl font-bold text-white capitalize">{userTier}</p>
            <p className="text-gray-500 text-sm">Membership Tier</p>
          </div>
        </div>

        <div className="grid grid-cols-1 lg:grid-cols-3 gap-8">
          {/* Main Content */}
          <div className="lg:col-span-2 space-y-8">
            {/* Continue Learning */}
            <div className="bg-white/5 border border-gold/10 rounded-2xl overflow-hidden">
              <div className="p-6 border-b border-gold/10">
                <h2 className="text-xl font-semibold text-white flex items-center space-x-2">
                  <Play className="w-5 h-5 text-gold" />
                  <span>Continue Learning</span>
                </h2>
              </div>
              <div className="p-6">
                <div className="flex flex-col sm:flex-row items-start gap-6">
                  <img
                    src={inProgressCourse.thumbnail}
                    alt={inProgressCourse.title}
                    className="w-full sm:w-48 h-32 object-cover rounded-xl"
                  />
                  <div className="flex-1">
                    <h3 className="text-white font-semibold text-lg mb-2">{inProgressCourse.title}</h3>
                    <p className="text-gray-400 text-sm mb-4 line-clamp-2">{inProgressCourse.description}</p>
                    
                    {/* Progress */}
                    <div className="mb-4">
                      <div className="flex items-center justify-between text-sm mb-2">
                        <span className="text-gray-500">Progress</span>
                        <span className="text-gold">35%</span>
                      </div>
                      <div className="h-2 bg-white/10 rounded-full overflow-hidden">
                        <div className="h-full w-[35%] bg-gradient-to-r from-crimson to-gold rounded-full" />
                      </div>
                    </div>

                    <button
                      onClick={() => {
                        setSelectedCourse(inProgressCourse.id);
                        setCurrentView('course-detail');
                      }}
                      className="flex items-center space-x-2 text-gold hover:text-gold/80 transition-colors"
                    >
                      <span>Continue Course</span>
                      <ArrowRight className="w-4 h-4" />
                    </button>
                  </div>
                </div>
              </div>
            </div>

            {/* Recommended Courses */}
            <div className="bg-white/5 border border-gold/10 rounded-2xl overflow-hidden">
              <div className="p-6 border-b border-gold/10 flex items-center justify-between">
                <h2 className="text-xl font-semibold text-white">Recommended For You</h2>
                <button
                  onClick={() => setCurrentView('courses')}
                  className="text-gold text-sm hover:underline"
                >
                  View All
                </button>
              </div>
              <div className="p-6">
                <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                  {COURSES.slice(1, 3).map((course) => (
                    <div
                      key={course.id}
                      onClick={() => {
                        setSelectedCourse(course.id);
                        setCurrentView('course-detail');
                      }}
                      className="flex items-center space-x-4 p-4 bg-white/5 rounded-xl cursor-pointer hover:bg-white/10 transition-colors"
                    >
                      <img
                        src={course.thumbnail}
                        alt={course.title}
                        className="w-16 h-16 object-cover rounded-lg"
                      />
                      <div>
                        <h4 className="text-white font-medium text-sm line-clamp-1">{course.title}</h4>
                        <p className="text-gray-500 text-xs">{course.lessons} lessons • {course.duration} min</p>
                      </div>
                    </div>
                  ))}
                </div>
              </div>
            </div>
          </div>

          {/* Sidebar */}
          <div className="space-y-6">
            {/* Upcoming Live Session */}
            <div className="bg-gradient-to-br from-crimson/20 to-gold/20 border border-gold/30 rounded-2xl p-6">
              <div className="flex items-center space-x-3 mb-4">
                <div className="w-10 h-10 bg-crimson/30 rounded-xl flex items-center justify-center">
                  <Calendar className="w-5 h-5 text-crimson" />
                </div>
                <div>
                  <h3 className="text-white font-semibold">Next Live Session</h3>
                  <p className="text-gray-400 text-xs">{formatDate(userData.nextLiveSession)}</p>
                </div>
              </div>
              <p className="text-gray-300 text-sm mb-4">
                "Nervous System Regulation & Emotional Intelligence"
              </p>
              <button
                onClick={() => setCurrentView('community')}
                className="w-full py-2 bg-white/10 border border-gold/30 text-white rounded-xl text-sm font-medium hover:bg-white/20 transition-colors"
              >
                Set Reminder
              </button>
            </div>

            {/* Quick Actions */}
            <div className="bg-white/5 border border-gold/10 rounded-2xl p-6">
              <h3 className="text-white font-semibold mb-4">Quick Actions</h3>
              <div className="space-y-3">
                <button
                  onClick={() => setCurrentView('journal')}
                  className="w-full flex items-center space-x-3 p-3 bg-white/5 rounded-xl hover:bg-white/10 transition-colors text-left"
                >
                  <FileText className="w-5 h-5 text-gold" />
                  <span className="text-gray-300 text-sm">Open Journal</span>
                </button>
                <button
                  onClick={() => setCurrentView('booking')}
                  className="w-full flex items-center space-x-3 p-3 bg-white/5 rounded-xl hover:bg-white/10 transition-colors text-left"
                >
                  <Calendar className="w-5 h-5 text-gold" />
                  <span className="text-gray-300 text-sm">Book a Session</span>
                </button>
                <button
                  onClick={() => setCurrentView('store')}
                  className="w-full flex items-center space-x-3 p-3 bg-white/5 rounded-xl hover:bg-white/10 transition-colors text-left"
                >
                  <BookOpen className="w-5 h-5 text-gold" />
                  <span className="text-gray-300 text-sm">Browse Resources</span>
                </button>
              </div>
            </div>

            {/* Upgrade CTA (for free users) */}
            {userTier === 'free' && (
              <div className="bg-gradient-to-br from-gold/10 to-crimson/10 border border-gold/30 rounded-2xl p-6 text-center">
                <Sparkles className="w-8 h-8 text-gold mx-auto mb-3" />
                <h3 className="text-white font-semibold mb-2">Unlock Full Access</h3>
                <p className="text-gray-400 text-sm mb-4">
                  Upgrade to access all courses, live sessions, and community features.
                </p>
                <button
                  onClick={() => setCurrentView('pricing')}
                  className="w-full py-2 bg-gradient-to-r from-crimson to-gold text-white rounded-xl text-sm font-medium hover:opacity-90 transition-opacity"
                >
                  View Plans
                </button>
              </div>
            )}
          </div>
        </div>
      </div>
    </section>
  );
};

export default DashboardSection;
