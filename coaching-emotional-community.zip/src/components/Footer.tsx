import React from 'react';
import { Mail, Instagram, Youtube, Heart } from 'lucide-react';

interface FooterProps {
  setCurrentView: (view: string) => void;
}

const Footer: React.FC<FooterProps> = ({ setCurrentView }) => {
  const currentYear = new Date().getFullYear();

  const footerLinks = {
    platform: [
      { label: 'Courses', view: 'courses' },
      { label: 'Community', view: 'community' },
      { label: 'Store', view: 'store' },
      { label: 'Book a Session', view: 'booking' }
    ],
    resources: [
      { label: 'Free Course', view: 'courses' },
      { label: 'Journal', view: 'journal' },
      { label: 'Blog', view: 'home' },
      { label: 'Podcast', view: 'home' }
    ],
    support: [
      { label: 'Help Center', view: 'home' },
      { label: 'Contact Us', view: 'home' },
      { label: 'FAQ', view: 'pricing' },
      { label: 'Accessibility', view: 'home' }
    ],
    legal: [
      { label: 'Privacy Policy', view: 'home' },
      { label: 'Terms of Service', view: 'home' },
      { label: 'Cookie Policy', view: 'home' },
      { label: 'Disclaimer', view: 'home' }
    ]
  };

  return (
    <footer className="bg-charcoal border-t border-gold/10">
      {/* Main Footer */}
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-16">
        <div className="grid grid-cols-2 md:grid-cols-6 gap-8">
          {/* Brand Column */}
          <div className="col-span-2">
            <div className="flex items-center mb-4">
              <div className="w-10 h-10 rounded-full bg-gradient-to-br from-crimson to-gold flex items-center justify-center mr-3">
                <span className="text-white font-serif text-xl">E</span>
              </div>
              <div>
                <h3 className="text-white font-serif text-lg">The Emotional</h3>
                <p className="text-gold text-xs tracking-widest uppercase">Alchemist</p>
              </div>
            </div>
            <p className="text-gray-400 text-sm mb-6 max-w-xs">
              Transform your emotional landscape. Move from survival mode to sovereignty with expert guidance and a supportive community.
            </p>
            
            {/* Social Links */}
            <div className="flex items-center space-x-4">
              <a
                href="https://instagram.com"
                target="_blank"
                rel="noopener noreferrer"
                className="w-10 h-10 bg-white/5 border border-gold/20 rounded-lg flex items-center justify-center text-gray-400 hover:text-gold hover:border-gold/40 transition-colors"
              >
                <Instagram className="w-5 h-5" />
              </a>
              <a
                href="https://youtube.com"
                target="_blank"
                rel="noopener noreferrer"
                className="w-10 h-10 bg-white/5 border border-gold/20 rounded-lg flex items-center justify-center text-gray-400 hover:text-gold hover:border-gold/40 transition-colors"
              >
                <Youtube className="w-5 h-5" />
              </a>
              <a
                href="mailto:hello@emotionalalchemist.com"
                className="w-10 h-10 bg-white/5 border border-gold/20 rounded-lg flex items-center justify-center text-gray-400 hover:text-gold hover:border-gold/40 transition-colors"
              >
                <Mail className="w-5 h-5" />
              </a>
            </div>
          </div>

          {/* Platform Links */}
          <div>
            <h4 className="text-white font-semibold mb-4">Platform</h4>
            <ul className="space-y-3">
              {footerLinks.platform.map((link) => (
                <li key={link.label}>
                  <button
                    onClick={() => setCurrentView(link.view)}
                    className="text-gray-400 hover:text-gold transition-colors text-sm"
                  >
                    {link.label}
                  </button>
                </li>
              ))}
            </ul>
          </div>

          {/* Resources Links */}
          <div>
            <h4 className="text-white font-semibold mb-4">Resources</h4>
            <ul className="space-y-3">
              {footerLinks.resources.map((link) => (
                <li key={link.label}>
                  <button
                    onClick={() => setCurrentView(link.view)}
                    className="text-gray-400 hover:text-gold transition-colors text-sm"
                  >
                    {link.label}
                  </button>
                </li>
              ))}
            </ul>
          </div>

          {/* Support Links */}
          <div>
            <h4 className="text-white font-semibold mb-4">Support</h4>
            <ul className="space-y-3">
              {footerLinks.support.map((link) => (
                <li key={link.label}>
                  <button
                    onClick={() => setCurrentView(link.view)}
                    className="text-gray-400 hover:text-gold transition-colors text-sm"
                  >
                    {link.label}
                  </button>
                </li>
              ))}
            </ul>
          </div>

          {/* Legal Links */}
          <div>
            <h4 className="text-white font-semibold mb-4">Legal</h4>
            <ul className="space-y-3">
              {footerLinks.legal.map((link) => (
                <li key={link.label}>
                  <button
                    onClick={() => setCurrentView(link.view)}
                    className="text-gray-400 hover:text-gold transition-colors text-sm"
                  >
                    {link.label}
                  </button>
                </li>
              ))}
            </ul>
          </div>
        </div>

        {/* Newsletter */}
        <div className="mt-12 pt-8 border-t border-gold/10">
          <div className="flex flex-col md:flex-row items-center justify-between gap-6">
            <div>
              <h4 className="text-white font-semibold mb-1">Join the Alchemy Newsletter</h4>
              <p className="text-gray-400 text-sm">Weekly wisdom for your transformation journey.</p>
            </div>
            <div className="flex w-full md:w-auto">
              <input
                type="email"
                placeholder="Enter your email"
                className="flex-1 md:w-64 px-4 py-3 bg-white/5 border border-gold/20 rounded-l-xl text-white placeholder-gray-500 focus:outline-none focus:border-gold/50"
              />
              <button className="px-6 py-3 bg-gradient-to-r from-crimson to-gold text-white rounded-r-xl font-medium hover:opacity-90 transition-opacity">
                Subscribe
              </button>
            </div>
          </div>
        </div>
      </div>

      {/* Bottom Bar */}
      <div className="border-t border-gold/10">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-6">
          <div className="flex flex-col md:flex-row items-center justify-between gap-4 text-sm text-gray-500">
            <p>© {currentYear} The Emotional Alchemist. All rights reserved.</p>
            <p className="flex items-center space-x-1">
              <span>Made with</span>
              <Heart className="w-4 h-4 text-crimson fill-current" />
              <span>for your transformation</span>
            </p>
          </div>
        </div>
      </div>

      {/* Disclaimer */}
      <div className="bg-charcoal/50 border-t border-gold/5">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-4">
          <p className="text-xs text-gray-600 text-center">
            <strong>Disclaimer:</strong> The Emotional Alchemist provides coaching and educational content, not medical or mental health treatment. 
            If you are experiencing a mental health crisis, please contact a licensed mental health professional or call your local emergency services.
          </p>
        </div>
      </div>
    </footer>
  );
};

export default Footer;
