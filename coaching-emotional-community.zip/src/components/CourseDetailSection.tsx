import React, { useState } from 'react';
import { ArrowLeft, Play, Lock, CheckCircle, Clock, BookOpen, FileText, Download, Upload, ChevronDown, ChevronUp } from 'lucide-react';
import { COURSES } from '@/lib/constants';

interface CourseDetailSectionProps {
  courseId: string;
  userTier: string;
  setCurrentView: (view: string) => void;
}

// Sample lessons data
const SAMPLE_LESSONS = [
  {
    id: '1',
    title: 'Introduction: Understanding Your Inner Critic',
    description: 'Learn what the inner critic is and why it exists.',
    duration: 12,
    type: 'video',
    completed: true,
    videoUrl: 'https://www.youtube.com/embed/dQw4w9WgXcQ'
  },
  {
    id: '2',
    title: 'The Neuroscience of Self-Criticism',
    description: 'Explore the brain science behind self-critical thoughts.',
    duration: 15,
    type: 'video',
    completed: true,
    videoUrl: 'https://www.youtube.com/embed/dQw4w9WgXcQ'
  },
  {
    id: '3',
    title: 'Identifying Your Critic\'s Voice',
    description: 'Learn to recognize when your inner critic is speaking.',
    duration: 10,
    type: 'video',
    completed: false,
    videoUrl: 'https://www.youtube.com/embed/dQw4w9WgXcQ'
  },
  {
    id: '4',
    title: 'Transforming the Inner Critic',
    description: 'Practical techniques for shifting your inner dialogue.',
    duration: 18,
    type: 'video',
    completed: false,
    videoUrl: 'https://www.youtube.com/embed/dQw4w9WgXcQ'
  }
];

const CourseDetailSection: React.FC<CourseDetailSectionProps> = ({ courseId, userTier, setCurrentView }) => {
  const course = COURSES.find(c => c.id === courseId);
  const [activeLesson, setActiveLesson] = useState<string | null>(null);
  const [completedLessons, setCompletedLessons] = useState<Set<string>>(new Set(['1', '2']));
  const [journalContent, setJournalContent] = useState('');
  const [showResources, setShowResources] = useState(false);

  if (!course) {
    return (
      <section className="py-20 px-4 sm:px-6 lg:px-8 bg-charcoal min-h-screen">
        <div className="max-w-4xl mx-auto text-center">
          <p className="text-gray-400">Course not found.</p>
          <button
            onClick={() => setCurrentView('courses')}
            className="mt-4 text-gold hover:underline"
          >
            Back to courses
          </button>
        </div>
      </section>
    );
  }

  const tierOrder = { free: 0, paid: 1, vip: 2 };
  const hasAccess = tierOrder[userTier as keyof typeof tierOrder] >= tierOrder[course.tier as keyof typeof tierOrder];

  const currentLessonIndex = SAMPLE_LESSONS.findIndex(l => !completedLessons.has(l.id));
  const currentLesson = activeLesson 
    ? SAMPLE_LESSONS.find(l => l.id === activeLesson) 
    : SAMPLE_LESSONS[currentLessonIndex >= 0 ? currentLessonIndex : 0];

  const canAccessLesson = (lessonIndex: number) => {
    if (lessonIndex === 0) return true;
    return completedLessons.has(SAMPLE_LESSONS[lessonIndex - 1].id);
  };

  const markComplete = (lessonId: string) => {
    setCompletedLessons(prev => new Set([...prev, lessonId]));
  };

  const progress = Math.round((completedLessons.size / SAMPLE_LESSONS.length) * 100);

  return (
    <section className="py-20 px-4 sm:px-6 lg:px-8 bg-charcoal min-h-screen">
      <div className="max-w-7xl mx-auto">
        {/* Back Button */}
        <button
          onClick={() => setCurrentView('courses')}
          className="flex items-center space-x-2 text-gray-400 hover:text-white mb-8 transition-colors"
        >
          <ArrowLeft className="w-5 h-5" />
          <span>Back to Courses</span>
        </button>

        {!hasAccess ? (
          /* Locked Course View */
          <div className="text-center py-16">
            <div className="w-24 h-24 bg-gold/20 rounded-full flex items-center justify-center mx-auto mb-6">
              <Lock className="w-12 h-12 text-gold" />
            </div>
            <h2 className="text-3xl font-serif text-white mb-4">{course.title}</h2>
            <p className="text-gray-400 max-w-lg mx-auto mb-8">{course.description}</p>
            <p className="text-gold mb-6">
              This course requires {course.tier === 'paid' ? 'Alchemist' : 'Sovereign'} membership.
            </p>
            <button
              onClick={() => setCurrentView('pricing')}
              className="px-8 py-3 bg-gradient-to-r from-crimson to-gold text-white rounded-xl font-semibold hover:opacity-90 transition-opacity"
            >
              Upgrade to Access
            </button>
          </div>
        ) : (
          <div className="grid grid-cols-1 lg:grid-cols-3 gap-8">
            {/* Main Content */}
            <div className="lg:col-span-2 space-y-6">
              {/* Video Player */}
              <div className="bg-white/5 border border-gold/10 rounded-2xl overflow-hidden">
                <div className="aspect-video bg-black">
                  {currentLesson && (
                    <iframe
                      src={currentLesson.videoUrl}
                      title={currentLesson.title}
                      className="w-full h-full"
                      allow="accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture"
                      allowFullScreen
                    />
                  )}
                </div>
                
                {/* Lesson Info */}
                <div className="p-6">
                  <div className="flex items-start justify-between mb-4">
                    <div>
                      <h2 className="text-xl font-semibold text-white mb-2">
                        {currentLesson?.title}
                      </h2>
                      <p className="text-gray-400 text-sm">{currentLesson?.description}</p>
                    </div>
                    {currentLesson && !completedLessons.has(currentLesson.id) && (
                      <button
                        onClick={() => markComplete(currentLesson.id)}
                        className="flex items-center space-x-2 px-4 py-2 bg-green-500/20 text-green-400 rounded-lg text-sm font-medium hover:bg-green-500/30 transition-colors"
                      >
                        <CheckCircle className="w-4 h-4" />
                        <span>Mark Complete</span>
                      </button>
                    )}
                  </div>

                  {/* Progress */}
                  <div className="flex items-center space-x-4 text-sm text-gray-500">
                    <div className="flex items-center space-x-1">
                      <Clock className="w-4 h-4" />
                      <span>{currentLesson?.duration} min</span>
                    </div>
                    <div className="flex items-center space-x-1">
                      <BookOpen className="w-4 h-4" />
                      <span>Lesson {SAMPLE_LESSONS.findIndex(l => l.id === currentLesson?.id) + 1} of {SAMPLE_LESSONS.length}</span>
                    </div>
                  </div>
                </div>
              </div>

              {/* Journal Section */}
              <div className="bg-white/5 border border-gold/10 rounded-2xl p-6">
                <h3 className="text-lg font-semibold text-white mb-4 flex items-center space-x-2">
                  <FileText className="w-5 h-5 text-gold" />
                  <span>Reflection Journal</span>
                </h3>
                <textarea
                  value={journalContent}
                  onChange={(e) => setJournalContent(e.target.value)}
                  placeholder="What insights are emerging for you? What patterns do you notice?"
                  className="w-full h-32 bg-white/5 border border-gold/20 rounded-xl p-4 text-gray-300 placeholder-gray-600 resize-none focus:outline-none focus:border-gold/50"
                />
                <div className="flex items-center justify-between mt-4">
                  <span className="text-gray-500 text-sm">{journalContent.split(/\s+/).filter(Boolean).length} words</span>
                  <button className="px-4 py-2 bg-gold/20 text-gold rounded-lg text-sm font-medium hover:bg-gold/30 transition-colors">
                    Save to Journal
                  </button>
                </div>
              </div>

              {/* Resources */}
              <div className="bg-white/5 border border-gold/10 rounded-2xl overflow-hidden">
                <button
                  onClick={() => setShowResources(!showResources)}
                  className="w-full p-6 flex items-center justify-between text-left"
                >
                  <h3 className="text-lg font-semibold text-white flex items-center space-x-2">
                    <Download className="w-5 h-5 text-gold" />
                    <span>Lesson Resources</span>
                  </h3>
                  {showResources ? (
                    <ChevronUp className="w-5 h-5 text-gray-400" />
                  ) : (
                    <ChevronDown className="w-5 h-5 text-gray-400" />
                  )}
                </button>
                
                {showResources && (
                  <div className="px-6 pb-6 space-y-3">
                    <div className="flex items-center justify-between p-3 bg-white/5 rounded-lg">
                      <div className="flex items-center space-x-3">
                        <FileText className="w-5 h-5 text-crimson" />
                        <span className="text-gray-300 text-sm">Inner Critic Worksheet.pdf</span>
                      </div>
                      <button className="text-gold text-sm hover:underline">Download</button>
                    </div>
                    <div className="flex items-center justify-between p-3 bg-white/5 rounded-lg">
                      <div className="flex items-center space-x-3">
                        <FileText className="w-5 h-5 text-crimson" />
                        <span className="text-gray-300 text-sm">Reflection Questions.pdf</span>
                      </div>
                      <button className="text-gold text-sm hover:underline">Download</button>
                    </div>
                  </div>
                )}
              </div>

              {/* Homework Upload */}
              <div className="bg-white/5 border border-gold/10 rounded-2xl p-6">
                <h3 className="text-lg font-semibold text-white mb-4 flex items-center space-x-2">
                  <Upload className="w-5 h-5 text-gold" />
                  <span>Submit Homework</span>
                </h3>
                <div className="border-2 border-dashed border-gold/20 rounded-xl p-8 text-center hover:border-gold/40 transition-colors cursor-pointer">
                  <Upload className="w-8 h-8 text-gray-500 mx-auto mb-3" />
                  <p className="text-gray-400 text-sm mb-2">Drag and drop your completed worksheet here</p>
                  <p className="text-gray-600 text-xs">PDF, DOC, or image files accepted</p>
                </div>
              </div>
            </div>

            {/* Sidebar - Lesson List */}
            <div className="lg:col-span-1">
              <div className="bg-white/5 border border-gold/10 rounded-2xl overflow-hidden sticky top-24">
                {/* Course Header */}
                <div className="p-6 border-b border-gold/10">
                  <h3 className="text-white font-semibold mb-2">{course.title}</h3>
                  <div className="flex items-center justify-between text-sm mb-3">
                    <span className="text-gray-500">Progress</span>
                    <span className="text-gold font-medium">{progress}%</span>
                  </div>
                  <div className="h-2 bg-white/10 rounded-full overflow-hidden">
                    <div 
                      className="h-full bg-gradient-to-r from-crimson to-gold rounded-full transition-all duration-500"
                      style={{ width: `${progress}%` }}
                    />
                  </div>
                </div>

                {/* Lessons List */}
                <div className="max-h-[500px] overflow-y-auto">
                  {SAMPLE_LESSONS.map((lesson, index) => {
                    const isCompleted = completedLessons.has(lesson.id);
                    const isActive = currentLesson?.id === lesson.id;
                    const isLocked = !canAccessLesson(index);

                    return (
                      <button
                        key={lesson.id}
                        onClick={() => !isLocked && setActiveLesson(lesson.id)}
                        disabled={isLocked}
                        className={`w-full p-4 flex items-start space-x-3 text-left border-b border-gold/5 transition-colors ${
                          isActive ? 'bg-gold/10' : isLocked ? 'opacity-50 cursor-not-allowed' : 'hover:bg-white/5'
                        }`}
                      >
                        <div className={`w-8 h-8 rounded-full flex items-center justify-center flex-shrink-0 ${
                          isCompleted ? 'bg-green-500/20' : isActive ? 'bg-gold/20' : 'bg-white/10'
                        }`}>
                          {isLocked ? (
                            <Lock className="w-4 h-4 text-gray-500" />
                          ) : isCompleted ? (
                            <CheckCircle className="w-4 h-4 text-green-400" />
                          ) : (
                            <Play className="w-4 h-4 text-gold" />
                          )}
                        </div>
                        <div className="flex-1 min-w-0">
                          <p className={`text-sm font-medium truncate ${
                            isActive ? 'text-gold' : 'text-white'
                          }`}>
                            {lesson.title}
                          </p>
                          <p className="text-xs text-gray-500 mt-1">{lesson.duration} min</p>
                        </div>
                      </button>
                    );
                  })}
                </div>
              </div>
            </div>
          </div>
        )}
      </div>
    </section>
  );
};

export default CourseDetailSection;
