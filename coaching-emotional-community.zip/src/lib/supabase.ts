import { createClient } from '@supabase/supabase-js';


// Initialize database client
const supabaseUrl = 'https://rkobzedcmqrajqrzxgcy.databasepad.com';
const supabaseKey = 'eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCIsImtpZCI6IjQ5YTI3OTljLTUyYzktNGE0OS1hMDhkLTNjOTBlZmY0NjdhMSJ9.eyJwcm9qZWN0SWQiOiJya29iemVkY21xcmFqcXJ6eGdjeSIsInJvbGUiOiJhbm9uIiwiaWF0IjoxNzY2MDMyMDMyLCJleHAiOjIwODEzOTIwMzIsImlzcyI6ImZhbW91cy5kYXRhYmFzZXBhZCIsImF1ZCI6ImZhbW91cy5jbGllbnRzIn0.Y8Ymxp6ztmh9jcNKbhladgr0o3DvEC9kzJGD7Alq2hc';
const supabase = createClient(supabaseUrl, supabaseKey);


export { supabase };