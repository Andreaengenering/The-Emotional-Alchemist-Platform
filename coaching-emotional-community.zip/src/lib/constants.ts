// Image URLs
export const IMAGES = {
  hero: 'https://d64gsuwffb70l.cloudfront.net/6943828997dec1bedde2cb2f_1766032965913_a28db8cc.png',
  coach: 'https://d64gsuwffb70l.cloudfront.net/6943828997dec1bedde2cb2f_1766033045532_136d1f5d.jpg',
  courses: [
    'https://d64gsuwffb70l.cloudfront.net/6943828997dec1bedde2cb2f_1766032985883_144b9049.png',
    'https://d64gsuwffb70l.cloudfront.net/6943828997dec1bedde2cb2f_1766032985347_ebff849e.png',
    'https://d64gsuwffb70l.cloudfront.net/6943828997dec1bedde2cb2f_1766032982340_a1b0042b.jpg',
    'https://d64gsuwffb70l.cloudfront.net/6943828997dec1bedde2cb2f_1766032983664_8bc9cb46.jpg',
    'https://d64gsuwffb70l.cloudfront.net/6943828997dec1bedde2cb2f_1766032985150_d47d87d1.jpg',
    'https://d64gsuwffb70l.cloudfront.net/6943828997dec1bedde2cb2f_1766032989303_f274c953.png',
  ],
  products: [
    'https://d64gsuwffb70l.cloudfront.net/6943828997dec1bedde2cb2f_1766033004507_b5cda46e.jpg',
    'https://d64gsuwffb70l.cloudfront.net/6943828997dec1bedde2cb2f_1766033008963_45e3d602.png',
    'https://d64gsuwffb70l.cloudfront.net/6943828997dec1bedde2cb2f_1766033011807_bc3cf4f6.png',
    'https://d64gsuwffb70l.cloudfront.net/6943828997dec1bedde2cb2f_1766033007256_8281a3f1.jpg',
    'https://d64gsuwffb70l.cloudfront.net/6943828997dec1bedde2cb2f_1766033016248_6faf42eb.png',
    'https://d64gsuwffb70l.cloudfront.net/6943828997dec1bedde2cb2f_1766033014314_981a281b.png',
  ]
};

// Sample courses data
export const COURSES = [
  {
    id: '11111111-1111-1111-1111-111111111111',
    title: 'The Biology of Your Inner Critic',
    description: 'Understand the neuroscience behind self-criticism and learn to transform your inner dialogue into a source of strength.',
    thumbnail: IMAGES.courses[0],
    tier: 'free',
    duration: 45,
    lessons: 4,
    progress: 0
  },
  {
    id: '22222222-2222-2222-2222-222222222222',
    title: 'Nervous System Mastery',
    description: 'Deep dive into polyvagal theory and practical techniques for regulating your autonomic nervous system.',
    thumbnail: IMAGES.courses[1],
    tier: 'paid',
    duration: 120,
    lessons: 8,
    progress: 0
  },
  {
    id: '33333333-3333-3333-3333-333333333333',
    title: 'Emotional Alchemy Foundations',
    description: 'The complete framework for transforming difficult emotions into wisdom and personal power.',
    thumbnail: IMAGES.courses[2],
    tier: 'paid',
    duration: 180,
    lessons: 12,
    progress: 0
  },
  {
    id: '44444444-4444-4444-4444-444444444444',
    title: 'Healing Attachment Wounds',
    description: 'Understand your attachment style and heal relational patterns that no longer serve you.',
    thumbnail: IMAGES.courses[3],
    tier: 'vip',
    duration: 150,
    lessons: 10,
    progress: 0
  },
  {
    id: '55555555-5555-5555-5555-555555555555',
    title: 'Somatic Release Practices',
    description: 'Body-based techniques for releasing stored trauma and restoring nervous system balance.',
    thumbnail: IMAGES.courses[4],
    tier: 'paid',
    duration: 90,
    lessons: 6,
    progress: 0
  },
  {
    id: '66666666-6666-6666-6666-666666666666',
    title: 'Shadow Work Integration',
    description: 'Explore and integrate the hidden parts of yourself for wholeness and authenticity.',
    thumbnail: IMAGES.courses[5],
    tier: 'vip',
    duration: 200,
    lessons: 14,
    progress: 0
  }
];

// Sample products data
export const PRODUCTS = [
  {
    id: 'aaaa1111-1111-1111-1111-111111111111',
    title: 'Sovereignty Scripts',
    description: 'A collection of powerful affirmations and scripts for reclaiming your emotional sovereignty.',
    price: 20,
    thumbnail: IMAGES.products[0],
    type: 'pdf'
  },
  {
    id: 'aaaa2222-2222-2222-2222-222222222222',
    title: 'Nervous System Reset Meditation',
    description: '45-minute guided meditation for deep nervous system regulation.',
    price: 15,
    thumbnail: IMAGES.products[1],
    type: 'audio'
  },
  {
    id: 'aaaa3333-3333-3333-3333-333333333333',
    title: 'Inner Critic Transformation Workbook',
    description: 'Comprehensive workbook with exercises to transform your inner critic.',
    price: 27,
    thumbnail: IMAGES.products[2],
    type: 'pdf'
  },
  {
    id: 'aaaa4444-4444-4444-4444-444444444444',
    title: 'Emotional Alchemy Masterclass',
    description: 'In-depth video masterclass on the complete emotional alchemy process.',
    price: 97,
    thumbnail: IMAGES.products[3],
    type: 'video'
  },
  {
    id: 'aaaa5555-5555-5555-5555-555555555555',
    title: 'Daily Regulation Toolkit',
    description: 'Quick-access tools and techniques for daily emotional regulation.',
    price: 35,
    thumbnail: IMAGES.products[4],
    type: 'pdf'
  },
  {
    id: 'aaaa6666-6666-6666-6666-666666666666',
    title: 'Shadow Work Journal Prompts',
    description: '100 powerful journal prompts for deep shadow work exploration.',
    price: 19,
    thumbnail: IMAGES.products[5],
    type: 'pdf'
  }
];

// Community posts sample data
export const COMMUNITY_POSTS = [
  {
    id: '1',
    author: 'The Emotional Alchemist',
    avatar: IMAGES.coach,
    content: 'How did you set a boundary today? Remember, boundaries are not walls—they are bridges to healthier relationships. Share your wins below.',
    isAdmin: true,
    isPinned: true,
    likes: 47,
    comments: 23,
    createdAt: new Date(Date.now() - 2 * 60 * 60 * 1000).toISOString()
  },
  {
    id: '2',
    author: 'The Emotional Alchemist',
    avatar: IMAGES.coach,
    content: 'New live session this Friday! We\'ll be exploring the intersection of nervous system regulation and emotional intelligence. Mark your calendars.',
    isAdmin: true,
    isPinned: false,
    likes: 89,
    comments: 31,
    createdAt: new Date(Date.now() - 24 * 60 * 60 * 1000).toISOString()
  },
  {
    id: '3',
    author: 'Sarah M.',
    avatar: null,
    content: 'Just completed Module 3 of the Emotional Alchemy course. The journaling exercise on identifying core wounds was incredibly powerful. Thank you for creating this space.',
    isAdmin: false,
    isPinned: false,
    likes: 34,
    comments: 8,
    createdAt: new Date(Date.now() - 3 * 24 * 60 * 60 * 1000).toISOString()
  }
];

// Tier pricing
export const TIERS = {
  free: {
    name: 'Free Seeker',
    price: 0,
    features: [
      'Access to free courses',
      'Community feed (read only)',
      'AI Assistant (limited)',
      'Weekly newsletter'
    ]
  },
  paid: {
    name: 'Alchemist',
    price: 47,
    features: [
      'All free features',
      'Full course library access',
      'Community participation',
      'Live stream access',
      'Unlimited AI Assistant',
      'Private journaling'
    ]
  },
  vip: {
    name: 'Sovereign',
    price: 147,
    features: [
      'All Alchemist features',
      'VIP-only courses',
      'Monthly group coaching call',
      'Priority booking',
      'Direct messaging with coach',
      'Exclusive resources'
    ]
  }
};
